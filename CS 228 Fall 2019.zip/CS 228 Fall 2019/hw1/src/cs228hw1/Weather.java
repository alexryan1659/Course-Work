package cs228hw1;

import java.util.Scanner;

import cs228hw1.stats.*;
/**
 ** @author Alex Thompson for CS228
 */
public class Weather {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		StatisticsShell<Double> ss = new StatisticsShell<>(null);
		Average<Double> a = new Average<>();
		Median<Double> m = new Median<>();
		Maximum<Double> ma = new Maximum<>();
		Minimum<Double> mi = new Minimum<>();
		Histogram<Double> h = new Histogram<>();
		h.SetMaxRange(110.0);
		h.SetMinRange(-40.0);
		h.SetNumberBins(15);
		
		ss.ReadFile(sc.next(), Statistics.DATA.TEMP);
		ss.AddStatObject(a);
		ss.AddStatObject(m);
		ss.AddStatObject(ma);
		ss.AddStatObject(mi);
		ss.AddStatObject(h);
		System.out.println(ss.MapCar());
		
		sc.close();
	}
}
