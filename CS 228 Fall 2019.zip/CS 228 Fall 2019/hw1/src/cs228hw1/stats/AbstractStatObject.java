package cs228hw1.stats;

import java.util.ArrayList;
/**
 ** @author Alex Thompson for CS228
 */
public abstract class AbstractStatObject<T extends Number> implements StatObject<T>{
	
	protected ArrayList<T> data;
	protected String desc;

	@Override
	public void SetDescription(String d) {
		desc = d;
	}

	@Override
	public String GetDescription() {
		return desc;
	}

	@Override
	public void SetData(ArrayList<T> data) {
		ArrayList<T> l = new ArrayList<>();
		for(T i: data) {
			l.add(i);
		}
		this.data = l;
	}

	@Override
	public ArrayList<T> GetData() {
		ArrayList<T> l = new ArrayList<>();
		for(T i : data) {
			l.add(i);
		}
		return (ArrayList<T>) l;
	}

	@Override
	public abstract ArrayList<T> GetResult() throws RuntimeException;
}
