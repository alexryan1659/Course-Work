package cs228hw1.stats;

import java.util.ArrayList;
/**
 ** @author Alex Thompson for CS228
 */
public class StdDeviation<T extends Number> extends AbstractStatObject<T> {
	
	public StdDeviation() {
		data = new ArrayList<T>();
		desc = "";
	}
	
	public StdDeviation(ArrayList<T> data) {
		this.data = data;
		desc = "";
	}

	@Override
	public ArrayList<T> GetResult() throws RuntimeException {
		ArrayList<Number> StdDev = new ArrayList<>();
		if(data == null || data.size() == 0) {
			throw new RuntimeException("Data object contains null or no data.");
		}
		
		if(data.size() == 1) {
			return (ArrayList<T>) data;
		}
		
		Average<T> a = new Average<T>();
		a.SetData(data);
		double mean = a.GetResult().get(0).doubleValue();
		double sd = 0;
		
		for(int i = 0; i != data.size(); i++) {
			if(data.get(i) != null) {
				sd += (Math.pow(data.get(i).doubleValue() - mean, 2));
			} else {
				sd += (Math.pow(0 - mean, 2));
			}
		}
		StdDev.add(Math.sqrt(sd/data.size()));
		return (ArrayList<T>) StdDev;
	}
}
