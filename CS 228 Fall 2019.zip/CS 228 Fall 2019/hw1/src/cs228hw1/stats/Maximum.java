package cs228hw1.stats;

import java.util.ArrayList;
/**
 ** @author Alex Thompson for CS228
 */
public class Maximum<T extends Number> extends AbstractStatObject<T> {
	
	public Maximum() {
		data = new ArrayList<T>();
		desc = "";
	}
	
	public Maximum(ArrayList<T> data) {
		this.data = data;
		desc = "";
	}

	@Override
	public ArrayList<T> GetResult() throws RuntimeException {
		ArrayList<Number> l = new ArrayList<>();
		
		if(data == null || data.size() == 0) {
			throw new RuntimeException("Data object is null or contains no data.");
		}
		
		if(data.size() == 1) {
			return (ArrayList<T>) data;
		}
		
		l.add(data.get(0));
		for(T i : data) {
			if(i != null) {
				if(i.doubleValue() > l.get(0).doubleValue()) {
					l.set(0, i);
				}
			}
		}
		return (ArrayList<T>) l;
	}
}
