package cs228hw1.stats;

import java.util.ArrayList;
/**
 ** @author Alex Thompson for CS228
 */
public class Median<T extends Number> extends AbstractStatObject<T> {
	
	public Median() {
		data = new ArrayList<T>();
		desc = "";
	}
	
	public Median(ArrayList<T> data) {
		this.data = data;
		desc = "";
	}

	@Override
	public ArrayList<T> GetResult() throws RuntimeException {
		
		if(data == null || data.size() == 0) {
			throw new RuntimeException("Data object is null or contains no data.");
		}
		
		if(data.size() == 1) {
			return (ArrayList<T>) data;
		}
		
		data.sort(null);
		ArrayList<Number> l = new ArrayList<Number>();
		if(data.size() % 2 == 1) {
			l.add(data.get(data.size()/2));
		} else { 
			l.add((data.get((data.size()/2)-1).doubleValue()/2) + (data.get((data.size()/2)).doubleValue()/2));
		}
		return (ArrayList<T>) l;
	}
}
