package cs228hw1.stats;

import java.util.ArrayList;

/**
 ** @author Alex Thompson for CS228
 */
public class Average<T extends Number> extends AbstractStatObject<T>{
	
	public Average() {
		data = new ArrayList<T>();
		desc = "";
	}
	
	public Average(ArrayList<T> data) {
		this.data = data;
		desc = "";
	}

	@Override
	public ArrayList<T> GetResult() throws RuntimeException {
		
		if(data == null || data.size() == 0) {
			throw new RuntimeException("Data object is null or contains no data.");
		}
		
		if(data.size() == 1) {
			return (ArrayList<T>) data;
		}
		
		ArrayList<Number> l = new ArrayList<Number>();
		Double total = 0.0;
		for(Number i : data) { 
			if(i == null) {
				total += 0.0;
			} else {
			total += i.doubleValue(); 
			}
		}
		l.add(total/data.size());
		return (ArrayList<T>) l;
	}
}
