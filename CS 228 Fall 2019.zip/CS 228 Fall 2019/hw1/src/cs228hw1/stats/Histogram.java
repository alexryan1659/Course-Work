package cs228hw1.stats;

import java.util.ArrayList;

/**
 ** @author Alex Thompson for CS228
 */
public class Histogram<T extends Number> extends AbstractStatObject<T> {
	
	private int binSize;
	private T maxRange;
	private T minRange;
	
	public Histogram() {
		maxRange = null;
		minRange = null;
		data = new ArrayList<T>();
		desc = "";
		binSize = 10;
	}
	
	public Histogram(ArrayList<T> data) {
		this.data = data;
		maxRange = null;
		minRange = null;
		desc = "";
		binSize = 10;
	}

	@Override
	public ArrayList<T> GetResult() throws RuntimeException {
		//complicated, and not sure what I was doing
		if(data == null || data.size() == 0) {
			throw new RuntimeException("Data object contains null or no data.");
		}
		if(minRange.doubleValue() > maxRange.doubleValue()) {
			throw new RuntimeException("Minimum range ("+(minRange)+") cannot be greater than Maximum range ("+(maxRange)+").");
		}
		Number binRange = (maxRange.doubleValue()-minRange.doubleValue())/binSize;
		if(binRange.doubleValue() == 0) {
			binRange = 1;
		}
		ArrayList<Number> l = new ArrayList<>();
		for(int b = 0; b != binSize; b++) {
			l.add(0);
		}
		ArrayList<Number> d = (ArrayList<Number>) data;

		for(Number i : d) {
			if(i == null) {
				i = 0.0;
			}
			Number bin = ((i.doubleValue() - minRange.doubleValue())/binRange.doubleValue());
			if(i.doubleValue() >= minRange.doubleValue() && i.doubleValue() < maxRange.doubleValue()) {
				l.set(bin.intValue(), l.get(bin.intValue()).intValue()+1);
			}
		} 
		return (ArrayList<T>)l;
	}
	
	/** Sets the number of bins for this histogram
	 * @param size - the number of bins to set**/
	public void SetNumberBins(int size) {
		binSize = size;
	}
	
	/** Sets the minimum range of this histogram
	 * @param range - the minimum range**/
	public void SetMinRange(T range) {
		minRange = range;
	}
	
	/** Sets the maximum range of this histogram
	 * @param range - the maximum range**/
	public void SetMaxRange(T range) {
		maxRange = range;
	}
	
	/** Returns the minimum range of this histogram; default is negative infinity**/
	public Number GetMinRange() {
		return minRange;
	}
	/** Returns the maximum range of this histogram; default is positive infinity**/
	public Number GetMaxRange() {
		return maxRange;
	}
}
