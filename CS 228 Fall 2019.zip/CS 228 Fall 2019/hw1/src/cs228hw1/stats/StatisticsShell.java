package cs228hw1.stats;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
/**
 ** @author Alex Thompson for CS228
 */
public class StatisticsShell<T extends Number> implements Statistics<T>, IParser<Number> {
	
	private ArrayList<T> data;
	private ArrayList<StatObject<T>> statobjects;
	private IParser<T> p;
	
	public StatisticsShell(IParser<T> i) {
		data = new ArrayList<T>();
		statobjects = new ArrayList<StatObject<T>>();
		p = i;
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean ReadFile(String path, DATA d) {
		File f = new File(path);
		try {
		Scanner sc = new Scanner(f);
		switch(d) {
		case USAF:
			sc.nextLine();
			while(sc.hasNextLine()) {
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case WBAN:
			sc.nextLine();
			while(sc.hasNextLine()) {
				sc.next();
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case YR_MO_DA_HR_MN:
			sc.nextLine();
			while(sc.hasNextLine()) {
				sc.next();
				sc.next();
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case DIR:
			sc.nextLine();
			while(sc.hasNextLine()) {
				sc.next();
				sc.next();
				sc.next();
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case SPD:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 4; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case GUS:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 5; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case CLG:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 6; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case SKC:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 7; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case L:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 8; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case M:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 9; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case H:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 10; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case VSB:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 11; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case MW_1:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 12; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case MW_2:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 13; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case MW_3:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 14; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case MW_4:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 15; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case AW_1:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 16; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case AW_2:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 17; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case AW_3:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 18; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case AW_4:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 19; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case W:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 20; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case TEMP:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 21; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case DEWP:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 22; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case SLP:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 23; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case ALT:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 24; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case STP:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 25; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case MAX:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 26; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case MIN:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 27; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case PCP01:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 28; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case PCP06:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 29; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case PCP24:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 30; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case PCPXX:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 31; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		case SD:
			sc.nextLine();
			while(sc.hasNextLine()) {
				for(int i = 0; i != 32; i++) {
					sc.next();
				}
				data.add((T) parse(sc.next()));
				sc.nextLine();
			}
			break;
		default:
			data.add(null);
			break;
			
		}
		sc.close();
		} catch (FileNotFoundException e) {
			return false;
		}
		return true;
	}

	@Override
	public void AddStatObject(StatObject<T> so) {
		so.SetData(data);
		statobjects.add(so);
	}

	@Override
	public void AddStatObject(StatObject<T> so, int first, int last) {
		ArrayList<T> l = new ArrayList<>();
		for(int i = first; i != last; i++) {
			l.add(data.get(i));
		}
		so.SetData(l);
		statobjects.add(so);
	}

	@Override
	public StatObject<T> GetStatObject(int i) {
		return statobjects.get(i);
	}

	@Override
	public StatObject<T> RemoveStatObject(int i) {
		if(i > statobjects.size() || i < 0) {
			return null;
		}
		StatObject<T> so = statobjects.get(i);
		statobjects.remove(i);
		
		return so;
	}

	@Override
	public int Count() {
		return statobjects.size();
	}

	@Override
	public ArrayList<T> GetDataSet() {
		ArrayList<T> l = new ArrayList<>();
		for(T i : data) {
			l.add((T) i);
		}
		return l;
	}

	@Override
	public ArrayList<ArrayList<T>> MapCar() {
		ArrayList<ArrayList<T>> l = new ArrayList<>();
		
		for(StatObject<T> so : statobjects) {
			l.add(so.GetResult());
		}
		return l;
	}

	@Override
	public Number parse(String str) {
		if(str.contains("*") || str.contains("T")) {
			return 0.0;
		}
		Number p = Double.parseDouble(str);
		return p.doubleValue();
	}
}