package cs228hw4.graph;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;


public class CS228DiGraph<V> implements DiGraph<V> {
	
	private TreeSet<V> vertices;
	private ArrayList<Edge> edges;
	
	public CS228DiGraph() {
		vertices = new TreeSet<V>();
		edges = new ArrayList<Edge>();
	}

	@Override
	public Set getNeighbors(V vertex) {
		Set<V> s = new TreeSet<>();
		for(Edge e : edges) {
			if(e.vertex1ID.equals(vertex)) {
				s.add(e.vertex2ID);
			}
		}
		return s;
	}

	@Override
	public int getEdgeCost(V start, V end) {
		for(Edge e : edges) {
			if(e.vertex1ID == start && e.vertex2ID == end) {
				return e.weight;
			}
		}
		return 0;
	}

	@Override
	public int numVertices() {
		return vertices.size();
	}

	@Override
	public Iterator<V> iterator() {
		return vertices.iterator();
	}
	
	public void addVertex(V data) {
		vertices.add(data);
	}
	
	public void addEdge(V v1, V v2, int cost) {
		if(vertices.contains(v1) && vertices.contains(v2)) {
			edges.add(new Edge(v1, v2, cost));
		}
	}
	
	public V getVertex(V data) {
		for(V v : vertices) {
			if(v == data) {
				return v;
			}
		}
		return null;
	}
	
	public Edge getEdge(V v1, V v2) {
		Edge r = null;
		for(Edge e : edges) {
			if(e.vertex1ID.equals(v1) && e.vertex2ID.equals(v2)) {
				r = e;
			}
		}
		return r;
	}
	
	private class Vertex {
		private V data;
		
		private Vertex(V data) {
			this.data = data;
		}
		
		private V getData() {
			return data;
		}
		
		@Override
		public String toString() {
			return data.toString();
		}
	}
	
	private class Edge {
		private V vertex1ID;
		private V vertex2ID;
		private int weight;
		
		private Edge(V id1, V id2, int weight) {
			vertex1ID = id1;
			vertex2ID = id2;
			this.weight = weight;
		}
		
		public String toString() {
			return vertex1ID +" to "+ vertex2ID +". Weight: " + weight;
		}
	}
}
