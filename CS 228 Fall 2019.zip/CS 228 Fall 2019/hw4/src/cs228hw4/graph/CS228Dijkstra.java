package cs228hw4.graph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * A program for finding the shortest path (as well as cost) 
 * through a graph to a given vertex.
 * 
 * @author Alex Thompson for CS 228
 *
 * @param <V> The data to represent as vertices
 */

public class CS228Dijkstra<V> implements Dijkstra<V> {

	/** Holds data for the supplied DiGraph*/
	private DiGraph<V> g;
	/** Keeps track of costs */
	private HashMap<V, Integer> distanceMap;
	/** Keeps track of predecessors of vertices, (initial, predecessor)*/
	private HashMap<V, V> predMap;
	
	/**
	 * Creates a new CS228Dijkstra using an instance of a DiGraph.
	 */
	public CS228Dijkstra(DiGraph<V> graph) {
		g = graph;
		distanceMap = new HashMap<>();
		predMap = new HashMap<>();
	}
	
	@Override
	public void run(V start) {
		distanceMap.clear();
		predMap.clear();
		//OpenSet is unvisited vertices, ClosedSet is visited vertices
		Set<V> OpenSet = new TreeSet<>();
		Set<V> ClosedSet = new TreeSet<>();
		//set all vertices to have distance "infinity". This works well for
		//getShortestDistance(v), if v can't be reach, it is MAX_VALUE
		
		for(V x : g) {
			OpenSet.add(x);
			distanceMap.put(x, Integer.MAX_VALUE);
			predMap.put(x, null);
		}
		
		//make sure the start has 0 cost
		distanceMap.replace(start, 0);
		
		while(!OpenSet.isEmpty()) {
			V a = getLowestCost(OpenSet); //get the lowest cost vertex from unvisited vertices
			OpenSet.remove(a);
			ClosedSet.add(a);
			
			for(V u : g.getNeighbors(a)) {
				if(!ClosedSet.contains(u)) {
					int alt = distanceMap.get(a) + g.getEdgeCost(a, u);
					if(alt < distanceMap.get(u)) {
						distanceMap.replace(u, alt);
						predMap.replace(u, a);
						OpenSet.add(u);
					}
				}
			}
		}
	}

	@Override
	public List<V> getShortestPath(V vertex) {
		ArrayList<V> r = new ArrayList<>();
		V cur = predMap.get(vertex);
		r.add(vertex);
		if(cur != null) {
			while(cur != null) {
				r.add(0,cur);
				cur = predMap.get(cur);
			}
		}
		return r;
	}

	@Override
	public int getShortestDistance(V vertex) {
		return distanceMap.get(vertex);
	}
	
	/**
	 * Gets the lowest cost of a vertex from a set of vertices. Used in run().
	 * @param s - set to get lowest cost from
	 * @return V - the vertex that has the lowest cost of all vertices in s.
	 */
	private V getLowestCost(Set<V> s) {
		V r = null;
		int k = Integer.MAX_VALUE;
		for(V x : s) {
			int i = distanceMap.get(x);
			if(i <= k) {
				k = i;
				r = x;
			}
		}
		return r;
	}
	
}
