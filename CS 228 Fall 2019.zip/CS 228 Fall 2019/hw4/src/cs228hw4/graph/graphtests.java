package cs228hw4.graph;

public class graphtests {
	
	public static void main(String[] args) {
		
		CS228DiGraph<String> g = new CS228DiGraph<>();
		
		CS228Dijkstra<String> d = new CS228Dijkstra<>(g);
		
		g.addVertex("A");
		g.addVertex("B");
		g.addVertex("C");
		g.addVertex("D");
		g.addEdge(g.getVertex("A"), g.getVertex("B"), 2);
		g.addEdge(g.getVertex("A"), g.getVertex("C"), 1);
		g.addEdge(g.getVertex("B"), g.getVertex("D"), 1);
		g.addEdge(g.getVertex("C"), g.getVertex("D"), 1);
		
		d.run("A");
		System.out.println(d.getShortestPath("D"));
		System.out.println(d.getShortestDistance("D"));
		
	}
}
