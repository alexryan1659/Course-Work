package cs228hw4.game;

import java.awt.Color;
import java.io.File;
import java.util.Random;

import edu.iastate.cs228.game.Agent;
import edu.iastate.cs228.game.GalaxyState;
import edu.iastate.cs228.game.SystemState;

public class MyAgent implements Agent {
	
	private File image;
	private Color color;
	private boolean firstRound = true;

	public MyAgent() {
		
	}
	
	@Override
	public String getFirstName() {
		return "Alex";
	}

	@Override
	public String getLastName() {
		return "Thompson";
	}

	@Override
	public String getStuID() {
		return "268093850";
	}

	@Override
	public String getUsername() {
		return "alexryan";
	}

	@Override
	public String getAgentName() {
		return "Callahan";
	}

	@Override
	public File getAgentImage() {
		return image;
	}

	@Override
	public boolean inTournament() {
		return true;
	}

	@Override
	public AgentAction[] getCommandTurnTournament(GalaxyState g, int energyLevel) {
		AgentAction a[] = {null, null, null};
		SystemState[] s = g.getCurrentSystemFor(color).getNeighbors();

		if(firstRound) {
			Random r = new Random();
			a[0] = new Capture(s[0].getCostToCapture());
			a[1] = new Refuel();
			a[2] = new Move(s[r.nextInt(s.length)].getName());
			
			firstRound = false;
			return a;
		}
		
		a[0] = new Refuel();
		for(SystemState x : s) {
			if(x.getOwner() != color) {
				a[1] = new Move(x.getName());
				a[2] = new Capture(x.getCostToCapture());
				break;
			}
		}
		if(g.getCurrentSystemFor(color).getOwner() != color) {
			a[1] = new Capture(g.getCurrentSystemFor(color).getCostToCapture());
			a[2] = new Fortify(2);
		} else {
			Random r = new Random();
			a[1] = new Move(s[r.nextInt(s.length)].getName());
			a[2] = new Refuel();
		}
		if(a[1] == null || a[2] == null) {
			a[1] = new Move(g.getCurrentSystemFor(color).getName());
			a[2] = new Refuel();
		}
		if(energyLevel <= 5) {
			int highestEnergy = 0;
			SystemState moveTo = null;
			for(SystemState x : s) {
				if(x.getEnergyStored() > highestEnergy) {
					highestEnergy = x.getEnergyStored();
					moveTo = x;
				}
			}
			a[1] = new Move(moveTo.getName());
			a[2] = new Refuel();
		}
		if(energyLevel > 100) {
			a[2] = new Fortify(100);
		}
		return a;
	}

	@Override
	public AgentAction[] getCommandTurnGrading(GalaxyState g, int energyLevel) {
		AgentAction a[] = {null, null, null};
		SystemState[] s = g.getCurrentSystemFor(color).getNeighbors();
		
		/*
		 * My general strategy is to brute-force
		 * capture systems, regardless of energy levels.
		 */

		//called at round start
		if(firstRound) {
			Random r = new Random();
			a[0] = new Capture(s[0].getCostToCapture());
			a[1] = new Refuel();
			a[2] = new Move(s[r.nextInt(s.length)].getName());
			
			firstRound = false;
			return a;
		}
		
		a[0] = new Refuel();
		//move to a system that isn't owned by me
		for(SystemState x : s) {
			if(x.getOwner() != color) {
				a[1] = new Move(x.getName());
				a[2] = new Capture(x.getCostToCapture());
				break;
			}
		}
		//if for some reason I don't own the system I'm in
		if(g.getCurrentSystemFor(color).getOwner() != color) {
			a[1] = new Capture(g.getCurrentSystemFor(color).getCostToCapture());
			a[2] = new Fortify(2);
		} else {
			Random r = new Random();
			a[1] = new Move(s[r.nextInt(s.length)].getName());
			a[2] = new Refuel();
		}
		if(a[1] == null || a[2] == null) {
			a[1] = new Move(g.getCurrentSystemFor(color).getName());
			a[2] = new Refuel();
		}
		//need more energy!
		if(energyLevel <= 5) {
			int highestEnergy = 0;
			SystemState moveTo = null;
			for(SystemState x : s) {
				if(x.getEnergyStored() > highestEnergy) {
					highestEnergy = x.getEnergyStored();
					moveTo = x;
				}
			}
			a[1] = new Move(moveTo.getName());
			a[2] = new Refuel();
		}
		//got some energy to spare. Might never be used.
		if(energyLevel > 100) {
			a[2] = new Fortify(60);
		}
		return a;
	}

	@Override
	public void setColor(Color c) {
		color = c;
	}

	@Override
	public void setOpponentColor(Color c) {
		// TODO Auto-generated method stub
		
	}

}
