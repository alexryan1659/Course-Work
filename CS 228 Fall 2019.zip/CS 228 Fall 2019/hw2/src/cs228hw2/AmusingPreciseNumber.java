package cs228hw2;

import java.io.Reader;
import java.util.ArrayList;

/**
 * A class that is capable of representing very large or very small numbers
 * with arbitrary precision, and performing basic operations on them
 * @author Alex Thompson for Com S 228
 *
 */
public class AmusingPreciseNumber {
	
	private ArrayList<Integer> apn;
	private int precision = -1;
	private boolean positive;
	
	/**
	 * Constructs an AmusingPreciseNumber using an int type
	 * @param numb - the number associated with this AmusingPreciseNumber
	 */
	public AmusingPreciseNumber(int numb) {
		if(numb < 0) {
			positive = false;
		} else { positive = true; }
		apn = new ArrayList<>();
		apn.add(numb);
		precision = -1;
	}
	/**
	 * Constructs an AmusingPreciseNumber from a string containing numbers
	 * @param numb - the String of numbers to read from
	 * @throws RuntimeException - if numb is found to contain an invalid character
	 */
	public AmusingPreciseNumber(String numb) throws RuntimeException {
		apn = new ArrayList<>();
		positive = true;
		try {
		if(numb.charAt(0) == '-') {
			positive = false;
			numb = numb.substring(1);
		} else if(numb.charAt(0) == '+'){ 
			numb = numb.substring(1);
			positive = true; 
		}
		for(int i = 0; i != numb.length(); i++) {
			if(numb.charAt(i) == '.') {
				precision = i;
			} else if(Character.isDigit(numb.charAt(i))){
			apn.add(Character.getNumericValue(numb.charAt(i)));
			}
			}
		} catch (Exception e) { throw new RuntimeException(); }
		if(!positive) {
			apn.set(0, apn.get(0) * -1);
		}
	}
	/** Constructs an AmusingPreciseNumber using a reader as input
	 * @param r - the Reader to read numbers from
	 */
	public AmusingPreciseNumber(Reader r) {
		this(read(r));
		
	}
	
	/**
	 * Reads numerical input from the standard input and passes it into the
	 * AmusingPreciseNumber(String) constructor. Called only when 
	 * AmusingPreciseNumber(Reader) is called.
	 * @param r the reader to read input from
	 * @return - a string to pass into the APN(string)
	 * @throws RuntimeException
	 */
	private static String read(Reader r) throws RuntimeException{
		StringBuilder s = new StringBuilder();
		char[] arr =  new char[100000];
		int size = 0;
		try {
			size = r.read(arr);
		} catch (Exception e) { throw new RuntimeException(); }
		char[] num = new char[size];
		for(int i = 0; i != size; i++) {
			num[i] = arr[i];
		}
		
		return s.append(num).toString();
	}
	
	/**
	 * Constructs an AmusingPreciseNumber by deep copying another APN
	 * @param numb - the AmusingPreciseNumber to copy from
	 */
	public AmusingPreciseNumber(AmusingPreciseNumber numb) {
		ArrayList<Integer> l = new ArrayList<>();
		for(Integer i : numb.apn) {
			l.add(i);
		}
		precision = numb.precision;
		apn = l;
	}
	/**
	 * Adds an AmusingPreciseNumber to this APN
	 * @param numb - the AmusingPreciseNumber to add to this APN
	 */
	public void add(AmusingPreciseNumber numb) {
		
		int n = toNumber(apn);
		int n2 = toNumber(numb.apn);
		String r = Integer.toString(n+n2);
		
		AmusingPreciseNumber result = new AmusingPreciseNumber(r);
		apn = result.apn;
	}
	
	/**
	 * Subtracts an AmusingPreciseNumber from this APN
	 * @param numb - the AmusingPreciseNumber to subtract from this APN
	 */
	public void subtract(AmusingPreciseNumber numb) {
		
		
		int n = toNumber(apn);
		int n2 = toNumber(numb.apn);
		String r = Integer.toString(n-n2);
		
		AmusingPreciseNumber result = new AmusingPreciseNumber(r);
		apn = result.apn;
		
	}
	/**
	 * Negates this AmusingPreciseNumber
	 */
	public void negate() {
		apn.set(0, apn.get(0) * -1);
		positive = !positive;
	}
	/**
	 * Takes the absolute value of this AmusingPreciseNumber
	 */
	public void abs() {
		apn.set(0, Math.abs(apn.get(0)));
		positive = true;
	}
	
	/**
	 * Adds two AmusingPreciseNumbers together and returns an APN
	 * @param numb1 - an APN to add
	 * @param numb2 - second APN to add
	 * @return AmusingPreciseNumber - the APN resulting from the addition
	 */
	public static AmusingPreciseNumber add(AmusingPreciseNumber numb1, 
			AmusingPreciseNumber numb2) {
		
		AmusingPreciseNumber result = new AmusingPreciseNumber(numb1);
		result.add(numb2);
		
		return result;
	}
	/**
	 * Subtracts two AmusingPreciseNumbers and returns an APN
	 * @param numb1 - an APN to subtract
	 * @param numb2 - second APN to subtract
	 * @return AmusingPreciseNumber - the APN resulting from the subtraction
	 */
	public static AmusingPreciseNumber subtract(AmusingPreciseNumber numb1, 
			AmusingPreciseNumber numb2) {
		
		AmusingPreciseNumber result = new AmusingPreciseNumber(numb1);
		result.subtract(numb2);
		
		return result;
	}
	/**
	 * Negates an AmusingPreciseNumber and returns a new APN that is the negation
	 * of the given APN
	 * @param numb - the APN to negate
	 * @return the resultant negated APN
	 */
	public static AmusingPreciseNumber negate(AmusingPreciseNumber numb) {
		AmusingPreciseNumber result = new AmusingPreciseNumber(numb);
		result.negate();
		
		return result;
	}
	/**
	 * Takes the absolute value of an AmusingPreciseNumber and returns a new APN
	 * that is the absolute value of the given APN
	 * @param numb - the APN to take the absolute value of
	 * @return the resultant absolute value APN
	 */
	public static AmusingPreciseNumber abs(AmusingPreciseNumber numb) {
		AmusingPreciseNumber result = new AmusingPreciseNumber(numb);
		result.abs();
		
		return result;
	}
	
	@Override
	public String toString() {
		String s = "";
		for(int i = 0; i != apn.size(); i++) {
			if(i == precision) {
				if(precision == -1) {
					 break;
				} else {
					s += '.';
				}
			}
			s += apn.get(i);
		}
		return s;
	}
	
	/** Converts an arraylist of integers to a proper int
	 * @param numb arraylist to convert
	 */
	private static int toNumber(ArrayList<Integer> numb) {
		int number = 0;
		
		int decimal = 1;
		for(int i = numb.size()-1; i != -1; i--) {
			number += numb.get(i)*decimal;
			decimal *= 10;
		}
		
		return number;
	}
}