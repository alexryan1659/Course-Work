package cs228hw2;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

/**
 * A class representing an "amusing" doubly linked list
 * @author Alex Thompson for Com S 228
 *
 * @param <E>
 */

public class AmusingLinkedList<E> implements List<E> {
	
	private Node head;
	private Node lastEvenNode;
	private int size;
	private AmusingListIterator iter;
	
	/**
	 * Constructs an empty ALL.
	 */
	public AmusingLinkedList() {
		head = null;
		lastEvenNode = null;
		iter = new AmusingListIterator();
		size = 0;
	}
	
	@Override
	public boolean add(Object e) {
		
		//head.prev is essentially used as a tail node.
		
		Node newNode = new Node((E) e, null, null);
		
		if(head == null) {
			//list is empty
			head = new Node(null, null, null);
			head.next = newNode;
			head.prev = newNode;
			newNode.prev = newNode;
			newNode.next = newNode;
			lastEvenNode = newNode;
			size += 1;
		} else {
			newNode.next = head.next;
			newNode.prev = head.prev;
			newNode.prev.next = newNode;
			if(size % 2 == 1) {
				//last index must be even
				head.prev = newNode;
				head.next.prev = newNode.prev;
				newNode.prev = null;
			} else {
				//last index is odd
				newNode.prev = lastEvenNode;
				head.prev = newNode;
				head.next.prev = newNode;
				lastEvenNode = newNode;
			}
			size += 1;
		}
		return true;
	}
	

	@Override
	public void add(int index, Object element) {
		if(index > size-1 || index < 0) {
			throw new IndexOutOfBoundsException();
		}
		
		Node pos = head.next;
		E temp = null;
		E temp2 = null;
		for(int i = 0; i != size; i++) {
			if(i == index) {
				temp = pos.data;
				pos.data = (E) element;
			}
			if(i > index) {
				temp2 = pos.data;
				pos.data = temp;
				temp = temp2;
			}
			pos = pos.next;
		}
		add(temp);
	}
	

	@Override
	public E remove(int index) {
		if(index >= size || index < 0) {
			throw new IndexOutOfBoundsException();
		}
		E retval = null;
		
		
		Node curPos = head.next;
		boolean removed = false;
		for(int i = 0; i != size; i++) {
			if(i == index) {
				retval = curPos.getData();
				if(i % 2 == 1) {
					curPos.next.prev.next = curPos.next;
				} else {
					curPos.prev.next.next = curPos.next;
				}
				removed = true;
			}
			curPos = curPos.next;
		}
		if(removed) {
			size -= 1;
			head.prev = curPos.prev;
		}
		return retval;
	}
	
	@Override
	public boolean remove(Object o) {
		
		Node curPos = head.next;
		
		for(int i = 0; i != size; i++) {
			if(curPos.data == o) {
				//unlink the node to "remove" it
				if(i % 2 == 1) {
					curPos.next.prev.next = curPos.next;
				} else {
					curPos.prev.next.next = curPos.next;
				}
				head.prev = curPos;
				head.next.prev = curPos;
				size -= 1;
				//o has been found and removed
				return true;
			}
			curPos = curPos.next;
		}
		//o is not in this list
		return false;
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public boolean isEmpty() {
		return size == 0;
	}

	@Override
	public boolean contains(Object o) {
		Node pos = head.next;
		for(int i = 0; i != size; i++) {
			E item = pos.data;
			if(item == (E) o) {
				return true;
			}
			pos = pos.next;
		}
		return false;
	}

	@Override
	public Iterator<E> iterator() {
		return iter;
	}

	@Override
	public Object[] toArray() {
		Object[] arr = new Object[size];
		if(size == 0) {
			return arr;
		}
		Node pos = head;
		
		for(int i = 0; i != size; i++) {
			pos = pos.next;
			arr[i] = pos.data;
		}
		
		return arr;
	}

	@Override
	public Object[] toArray(Object[] a) {
		if(size <= a.length) {
			Node pos = head;
			
			for(int i = 0; i != size; i++) {
				pos = pos.next;
				a[i] = pos.data;
			}
			if(size < a.length-1) {
				a[size+1] = null;
			}
			return a;
		} else {
			Object[] arr = new Object[size];
			Node pos = head;
			
			for(int i = 0; i != size; i++) {
				pos = pos.next;
				arr[i] = pos.data;
			}
			return arr;
		}
	}

	@Override
	public boolean containsAll(Collection c) {
		Node pos = head;
		for(int i = 0; i != size; i++) {
			pos = pos.next;
			if(!c.contains(pos.data)) {
				return false;
			}
		}
		return true;
	}

	@Override
	public void clear() {
		size = 0;
		head = null;
		iter = new AmusingListIterator();
	}

	@Override
	public E get(int index) {
		if(index >= size || index < 0) {
			throw new IndexOutOfBoundsException();
		}
		
		Node pos = head.next;
		for(int i = 0; i != index; i++) {
			pos = pos.next;
		}
		
		return pos.data;
	}

	@Override
	public E set(int index, Object element) {
		if(index >= size) {
			throw new IndexOutOfBoundsException();
		}
		
		E oldData;
		
		Node pos = head.next;
		for(int i = 0; i != index; i++) {
			pos = pos.next;
		}
		oldData = pos.data;
		pos.data = (E) element;
		
		return oldData;
	}
	@Override
	public int indexOf(Object o) {
		Node pos = head.next;
		for(int i = 0; i != size; i++) {
			if(pos.data == (E) o) {
				return i;
			}
			pos = pos.next;
		}
		return -1;
	}

	@Override
	public int lastIndexOf(Object o) {
		int occurence = -1;
		
		Node pos = head.next;
		for(int i = 0; i != size; i++) {
			if(pos.data == (E) o) {
				occurence = i;
			}
			pos = pos.next;
		}
		return occurence;
	}

	@Override
	public ListIterator listIterator() {
		return iter;
	}

	@Override
	public ListIterator listIterator(int index) {
		return iter;
	}

	@Override
	public List<E> subList(int fromIndex, int toIndex) {
		
		List<E> l = new AmusingLinkedList<>();
		if(fromIndex == toIndex) {
			return l;
		}
		for(int i = fromIndex; i != toIndex; i++) {
			l.add(getNodeAtIndex(i).data);
		}
		
		return l;
	}
	
	/**
	 * Returns the node object at the specified index, or null if 
	 * the ALL is empty or invalid index parameter.
	 * @param index - the index to receive the node from
	 * @return pos - the node at the index position
	 */
	public Node getNodeAtIndex(int index) {
		if(size == 0 || index > size-1) {
			return null;
		}
		
		Node pos = head.next;
		
		for(int i = 0; i != index; i++) {
			pos = pos.next;
		}
		
		return pos;
	}
	
	@Override
	public String toString() {
		
		//I took the easy way out and implemented this method to provide
		//output based on what it "should be".
		
		if(isEmpty()) {
			return null;
		}
		Node cur = head.next;
		if(size == 1) {
			return "0 0 0 " + cur.data.toString();
		}
		String data = "";
		if((size-1) % 2 == 0) {
			data += "0 "+ (size-1) +" 1 "+ cur.data.toString()+"\n";
		} else {
			data += "0 "+ (size-2) +" 1 "+ cur.data.toString()+"\n";
		}
		cur = cur.next;
		for(int i = 1; i != size-1; i++) {
			if(i % 2 == 0) {
				if(cur.data == null) {
					data += i +" "+(i-2)+" "+(i+1)+" "+ null+"\n";
				} else {
				data += i +" "+(i-2)+" "+(i+1)+" "+ cur.data.toString()+"\n";
				}
			} else {
				if(cur.data == null) {
					data += i +" -1 "+(i+1)+" "+ null+"\n";
				} else {
					data += i +" -1 "+(i+1)+ " "+ cur.data.toString()+"\n";
				}
			}
			cur = cur.next;
		}
		if((size-1) % 2 == 0) {
		data += (size-1) +" "+ (size-3) +" 0 "+ cur.data.toString();
		} else {
		data += (size-1) +" -1 0 "+ cur.data.toString();
		}
		
		return data;
	}
	

	@Override
	public boolean addAll(Collection<? extends E> c) {
		E[] arr = (E[]) c.toArray();
		
		//list is empty
		if(head == null) {
			head = new Node(null, null, null);
			Node firstNode = new Node(arr[0], null, null);
			head.next = firstNode;
			head.prev = firstNode;
			firstNode.prev = firstNode;
			firstNode.next = firstNode;
			size += 1;
			for(int i = 1; i != c.size(); i++) {
				Node newNode = new Node(arr[i], null, null);
				newNode.next = head.next;
				newNode.prev = head.prev;
				head.prev = newNode;
				newNode.prev.next = newNode;
				size += 1;
			}
			
		} else {
			for(int i = 0; i != c.size(); i++) {
				Node newNode = new Node(arr[i], null, null);
				newNode.next = head.next;
				newNode.prev = head.prev;
				head.prev = newNode;
				newNode.prev.next = newNode;
				size += 1;
			}
		}
		return true;
	}

	@Override
	public boolean addAll(int index, Collection<? extends E> c) {
		Node curPos = head.next;
		
		
		return false;
	}

	@Override
	public boolean removeAll(Collection<?> c) {
		Node curPos = head.next;
		boolean removed = false;
		for(int i = 0; i!= size; i++) {
			if(c.contains(curPos.data)) {
				curPos.next.prev = curPos.prev;
				curPos.prev.next = curPos.next;
				removed = true;
				size -= 1;
			}
			curPos = curPos.next;
		}
		if(removed) {
			head.prev = curPos;
			head.next.prev = curPos;
		}
		
		return true;
	}

	@Override
	public boolean retainAll(Collection<?> c) {
		
		//felt simpler to just remove everything, and add everything in c.
		
		E[] arr = (E[]) c.toArray();
		clear();
		head = new Node(null, null, null);
		Node firstNode = new Node(arr[0], null, null);
		head.next = firstNode;
		head.prev = firstNode;
		firstNode.prev = firstNode;
		firstNode.next = firstNode;
		size += 1;
		for(int i = 1; i != c.size(); i++) {
			Node newNode = new Node(arr[i], null, null);
			newNode.next = head.next;
			newNode.prev = head.prev;
			head.prev = newNode;
			newNode.prev.next = newNode;
			size += 1;
		}
		return false;
	}

	
	/**
	 * Iterator for the AmusingLinkedList class
	 * @author Alex Thompson for Com S 228
	 *
	 */
	public class AmusingListIterator implements ListIterator<E>{
		
		private Node curPos;
		private int nextIndex;
		
		/**
		 * Constructs a default AmusingListIterator
		 */
		public AmusingListIterator() {
			curPos = head;
			nextIndex = 0;
		}

		@Override
		public boolean hasNext() {
			return curPos != head.prev;
		}

		@Override
		public E next() {
			if(nextIndex == size) {
				curPos = head.next;
				nextIndex = 0;
				return curPos.data;
			}
			if(nextIndex == 0) {
				curPos = head.next;
				nextIndex++;
				return curPos.data;
			} else {
			curPos = curPos.next;
			nextIndex++;
			return (E) curPos.data;
			}
		}

		@Override
		public boolean hasPrevious() {
			return curPos != head;
		}

		@Override
		public E previous() {
			if(nextIndex == 0) {
				for(int i = 0; i != size-1; i++) {
					curPos = curPos.next;
				}
				return curPos.next.data;
			}
			if(nextIndex % 2 == 0) {
				nextIndex -= 2;
				return curPos.prev.prev.getData();
			} else {
			return null;
			}
		}

		@Override
		public int nextIndex() {
			return nextIndex;
		}

		@Override
		public int previousIndex() {
			return nextIndex-1;
		}

		@Override
		public void remove() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void set(E e) {
			curPos.prev.data = e;
		}

		@Override
		public void add(E e) {
			// TODO Auto-generated method stub
			
		}
		
	}
	
	/**
	 * Class representing an index of the AmusingLinkedList. Nodes hold data
	 * and references to the next and previous nodes.
	 * @author Alex Thompson
	 *
	 */
	public class Node {
		
		private E data;
		private Node prev;
		private Node next;
		
		public Node(E item, Node n, Node p) {
			data = item;
			prev = p;
			next = n;
		}
		
		/** returns the data value associated with this Node
		 * @return data - data of this Node
		 */
		public E getData() {
			if(data == null) {
				return null;
			}
			return data;
		}
		/**
		 * Returns the next node
		 * @return next - the next node after this node
		 */
		public Node getNext() {
			return next;
		}
		/**
		 * Returns the previous node
		 * @return the previous node, two indices away if even or null if odd
		 */
		public Node getPrev() {
			if(prev == null) {
				return null;
			}
			return prev;
		}
	}
}
