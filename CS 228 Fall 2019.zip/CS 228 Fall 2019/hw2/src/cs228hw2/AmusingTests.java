package cs228hw2;

import java.util.ArrayList;

public class AmusingTests {
	
	public static void main(String[] args) {

		AmusingLinkedList<String> x = new AmusingLinkedList<>();
		
		/*
		x.add("A");
		x.add("B");
		x.add("C");
		x.add("D");
		x.add("E");
		x.add("F");
		x.remove("A");
		//x.add("G");
		*/
		/*
		ArrayList<String> c = new ArrayList<>();
		c.add("C");
		c.add("D");
		c.add("E");
		*/
		
		String n1 = "10";
		String n2 = "1";
		AmusingPreciseNumber r = new AmusingPreciseNumber(n1);
		AmusingPreciseNumber r2 = new AmusingPreciseNumber(n2);
		r.subtract(r2);
		System.out.println(r);
		//System.out.println(x.getNodeAtIndex(4).getPrev().getData());
	}
}
