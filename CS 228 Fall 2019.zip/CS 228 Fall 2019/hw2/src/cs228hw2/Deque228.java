package cs228hw2;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
/**
 * Class representing a double ended queue, or "deque"
 * @author Alex Thompson for Com S 228
 *
 * @param <E>
 */
public class Deque228<E> {
	
	private ArrayList<E> queue;
	
	/**
	 * Constructs a default empty deque
	 */
	public Deque228() {
		queue = new ArrayList<>();
	}
	
	/**
	 * Determines if this Deque228 contains no elements
	 * @return true, if this list contains no elements, false otherwise
	 */
	public boolean isEmpty() {
		return queue.size() == 0;
	}

	/**
	 * Returns an array representation of this Deque228
	 * @return The elements of this Deque228 in an array form
	 */
	public E[] toArray() {
		return (E[]) queue.toArray();
	}

	/**
	 * Returns an array representation of this Deque228
	 * @param a
	 * @return
	 */
	public E[] toArray(Object[] a) {
		return (E[]) queue.toArray(a);
		}

	/**
	 * Determines if all the elements in the given collection are in this Deque228
	 * @param c - collection to check
	 * @return true, if all elements in c are in this Deque228, false otherwise
	 */
	public boolean containsAll(Collection<E> c) {
		return queue.containsAll(c);
	}

	/**
	 * Removes all elements in the given collection from this Deque228, if it contains them
	 * @param c - collection of elements to remove
	 * @return true if the list changed as a result of the call.
	 */
	public boolean removeAll(Collection<E> c) {
		return queue.removeAll(c);
	}

	/**
	 * Removes all but the specified elements in the collection
	 * @param c - the collection to retain
	 * @return true if the list changed after this call
	 */
	public boolean retainAll(Collection<E> c) {
		return queue.retainAll(c);
	}

	/**
	 * Removes all elements of this Deque228, rendering size to 0
	 */
	public void clear() {
		queue = new ArrayList<>();
	}

	/**
	 * Inserts the specified element at the front of this Deque228
	 * @param e - item to be added
	 */
	public void addFirst(E e) {
		queue.add(0,e);
	}

	/**
	 * Inserts the specified element to the back of this Deque228
	 * @param e - item to be added
	 */
	public void addLast(E e) {
		add(e);
	}

	/**
	 * Inserts the specified element to the front of this Deque228
	 * @param e - item to be added
	 * @return true
	 */
	public boolean offerFirst(E e) {
		queue.add(0,e);
		return true;
	}

	/**
	 * Inserts the specified element to the back of this Deque228
	 * @param e - item to be added
	 * @return true
	 */
	public boolean offerLast(E e) {
		add(e);
		return true;
	}

	/**
	 * Retrieves and removes the first element off of this Deque228
	 * @return E the value removed
	 */
	public E removeFirst() {
		E retval = queue.get(0);
		queue.remove(0);
		return retval;
	}
	
	/**
	 * Retrieves and removes the last element off of this Deque228
	 * @return E the value removed
	 */
	public E removeLast() {
		E retval = queue.get(size()-1);
		queue.remove(size()-1);
		return retval;
	}
	
	/**
	 * Retrieves and removes the first element of this Deque228, or null if empty
	 * @return E the value polled
	 */
	public E pollFirst() {
		if(isEmpty()) {
			return null;
		}
		E retval = queue.get(0);
		queue.remove(0);
		return retval;
	}
	/**
	 * Retrieves and removes the last element of this Deque228, or null if empty
	 * @return E the value polled
	 */
	public E pollLast() {
		if(isEmpty()) {
			return null;
		}
		E retval = queue.get(size()-1);
		queue.remove(size()-1);
		return retval;
	}

	/**
	 * Retrieves but does not remove the first element of this Deque228
	 * @return E the value retrieved
	 */
	public E getFirst() {
		if(isEmpty()) {
			return null;
		}
		return queue.get(0);
	}

	/**
	 * Retrieves but does not remove the last element of this Deque228
	 * @return E the value retrieved
	 */
	public E getLast() {
		if(isEmpty()) {
			return null;
		}
		return queue.get(size()-1);
	}

	/**
	 * Retrieves but does not remove the first element of this Deque228
	 * @return E the value retrieved
	 */
	public E peekFirst() {
		if(isEmpty()) {
			return null;
		}
		return queue.get(0);
	}

	/**
	 * Retrieves but does not remove the last element of this Deque228
	 * @return E the value retrieved
	 */
	public E peekLast() {
		if(isEmpty()) {
			return null;
		}
		return queue.get(size()-1);
	}

	/**
	 * Removes the first occurence of the specified element from this Deque228
	 * @param e - the item to remove
	 * @return true
	 */
	public boolean removeFirstOccurrence(E e) {
		queue.remove(e);
		return true;
	}

	/**
	 * Removes the first occurence of the specified element from this Deque228
	 * @param e - the item to remove
	 * @return true
	 */
	public boolean removeLastOccurrence(E e) {
		//yes, its inefficient
		int index = 0;
		int indexToRemove = 0;
		boolean found = false;
		for(int i = 0; i != queue.size(); i++) {
			if(queue.get(index) == e) {
				indexToRemove = index;
				found = true;
			}
			index++;
		}
		if(found) {
			queue.remove(indexToRemove);
		}
		return false;
	}

	/**
	 * Appends an object to the end of this Deque228
	 * @param e - object to add
	 * @return always true
	 */
	public boolean add(E e) {
		queue.add(e);
		return true;
	}
	
	/**
	 * Inserts the specified element at the END of this Deque228
	 * @param e - item to insert
	 * @return true
	 */
	public boolean offer(E e) {
		add(e);
		return true;
	}

	/**
	 * Removes the first item in this Deque228
	 * @return e - the object removed
	 */
	public E remove() {
		E retval = queue.get(0);
		queue.remove(0);
		return retval;
	}

	/**
	 * Retrieves and removes the head of the Deque228
	 * @return e - the object removed
	 */
	public E poll() {
		if(isEmpty()) {
			return null;
		}
		E retval = queue.get(0);
		queue.remove(0);
		return retval;
	}

	/**
	 * Retrieves but does not remove the first element of this Deque228
	 * @return e - the element peeked
	 */
	public E element() {
		return peek();
	}

	/**
	 * Retrieves but does not removes the first element of this Deque228
	 * @return e - the element peeked
	 */
	public E peek() {
		if(isEmpty()) {
			return null;
		}
		return queue.get(0);
	}

	/**
	 * Pushes the specified element at the HEAD of this Deque228
	 * @param e - item to add
	 */
	public void push(E e) {
		queue.add(0, e);
	}

	/**
	 * Pops (returns and removes) an element from the front of this Deque228
	 * @return e - the value popped
	 */
	public E pop() {
		E retval = queue.get(0);
		queue.remove(0);
		return retval;
	}

	/**
	 * Retrieves and removes the specified element from this Deque228
	 * @param o - object to remove, if found
	 * @return e - the element removed
	 */
	public E remove(E o) {
		queue.remove(o);
		return o;
	}

	/**
	 * Returns true if this Deque228 contains the specified element 
	 * @param o - the object to check for
	 * @return true, if the object is in this Deque228 false otherwise
	 */
	public boolean contains(E o) {
		if(queue.contains(o)) {
			return true;
		}
		return false;
	}

	/**
	 * Returns the size of this Deque228 in its current state
	 * @return int - number of elements in this Deque228
	 */
	public int size() {
		return queue.size();
	}

	/**
	 * Returns an iterator over the elements in this Deque228 in proper sequence
	 * @return Iterator in proper sequence
	 */
	public Iterator<E> iterator() {
		return queue.iterator();
	}

	/**
	 * Returns an iterator over the elements in this Deque228 in reverse
	 * @return Iterator in reverse
	 */
	public Iterator<E> descendingIterator() {
		return queue.iterator();
	}
	

}
