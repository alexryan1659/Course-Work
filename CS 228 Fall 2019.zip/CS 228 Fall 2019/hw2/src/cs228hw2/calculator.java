package cs228hw2;

import java.io.InputStream;
import java.util.Scanner;

public class calculator {
	
	public static void main(String[] args) {
		InputStream s = System.in;
		
		System.out.println(evaluateInput(s));
	}
	/**
	 * Evaluates the given input (in postfix order) and returns the result. Will return
	 * an error message if any invalid operators or operands are found.
	 * @param expression - the postfix operation to compute
	 * @return the result, in an AmusingPreciseNumber format, of computation
	 */
	static AmusingPreciseNumber evaluateInput(InputStream expression) {
		Deque228<AmusingPreciseNumber> d = new Deque228<>();
		
		Scanner sc = new Scanner(expression);
		sc = new Scanner(sc.nextLine());
		//make sure theres any input at all
		if(!sc.hasNext()) {
			System.out.println("No input to evaluate.");
			System.exit(1);
		}
		while(sc.hasNext()) {
			if(sc.hasNextInt() || sc.hasNextDouble()) {
				d.push(new AmusingPreciseNumber(sc.next()));
			} else {
				if(d.size() == 0) {
					System.out.println("Invalid Postfix expression.");
					System.exit(1);
				}
				AmusingPreciseNumber n1 = d.pollLast();
				
				String operator = sc.next();
				switch(operator) {
					case "+":
						try {
						n1.add(d.poll());
						d.push(n1);
						} catch (Exception e) { System.out.println(
								"Invalid Postfix expression"); }
						break;
					case "-":
						try {
						n1.subtract(d.poll());
						d.push(n1);
						} catch (Exception e) { System.out.println(
								"Invalid Postfix expression");
						}
						break;
					case "abs":
						try {
						n1.abs();
						d.push(n1);
						} catch (Exception e) { System.out.println(
								"Invalid Postfix expression");
						}
						break;
					case "neg":
						try {
						n1.negate();
						d.push(n1);
						} catch (Exception e) { System.out.println(
								"Invalid Postfix expression");
						}
						break;
					default :
						System.out.println("Invalid operator or operand found.");
						System.exit(1);
				} 
			}
		}
		sc.close();
		return d.pop();
	}
	
}
