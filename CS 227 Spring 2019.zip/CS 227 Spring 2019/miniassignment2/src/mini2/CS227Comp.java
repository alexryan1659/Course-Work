package mini2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class CS227Comp {
	
	public static final int READ = 10;
	public static final int WRITE = 20;
	public static final int LOAD = 30;
	public static final int STORE = 40;
	public static final int ADD = 50;
	public static final int SUB = 51;
	public static final int DIV = 52;
	public static final int MOD = 53;
	public static final int MUL = 54;
	public static final int JUMP = 60;
	public static final int JUMPN = 61;
	public static final int JUMPZ = 63;
	public static final int HALT = 80;
	
	private int accumulator;
	private int instructionCounter;
	private int instructionRegister;
	
	private int memorySize;
	
	private int[] memory;
	
	private boolean halted;

	public CS227Comp(int memorySize) {
		this.memorySize = memorySize;
		memory = new int[memorySize];
	}
	
	public CS227Comp(int initialIC, int initialAC, int[] memoryImage) {
		this.memorySize = memoryImage.length;
		memory = new int[memorySize];
		this.loadMemoryImage(memoryImage);
		accumulator = initialAC;
		instructionCounter = initialIC;
	}
	
	public void runProgram() {
		while(!halted) {
			nextInstruction();
		}
	}
	public void dumpCore() {
		System.out.printf("REGISTERS:\n");
	    System.out.printf("%-20s %+05d\n", "accumulator", getAC());
	    System.out.printf("%-20s    %02d\n", "instruction counter",
	                      getIC());
	    System.out.printf("%-20s %+05d\n", "instruction register",
	                      getIR());
	    System.out.printf("%-20s    %02d\n", "operation code", getIR() / 100);
	    System.out.printf("%-20s    %02d\n", "operand", getIR() % 100);
	    System.out.printf("\nMEMORY:\n  ");
	    for (int i = 0; i < 10; i++) {
	      System.out.printf("%6d", i);
	    }
	    int row = 0;
	    for (int i = 0; i < getMemorySize(); i++)
	    {
	      if (i % 10 == 0)
	      {
	        row += 1;
	        System.out.printf("\n%2d ", row * 10);
	      }
	      System.out.printf("%+05d ", peekMemory(i));        
	    }
	    System.out.println();
	}
	
	public void loadMemoryImage(int[] image) {
		if(image.length < memory.length) {
			for(int i = 0; i != image.length; i++) {
				memory[i] = image[i];
			}
			for(int i = memory.length - 1; i != image.length - 1; i--) {
				memory[i] = 0;
			}
			
		} else if (image.length > memory.length) {
			for(int i = 0; i != memory.length; i++) {
				memory[i] = image[i];
			}
			
		} else {
			for(int i = 0; i != image.length; i++) {
				memory[i] = image[i];
			}
		}
		
	}
	
	public void loadProgramFromConsole() {
		Scanner sc = new Scanner(System.in);
		
		int instr = sc.nextInt();
		
		int i = 0;
		
		while(instr != -99999) {
			if (instr < -9999 || instr > 9999) {
				halted = true;
				System.out.println("*** Invalid input ***");
				break;
			}
			
			memory[i] = instr;
			
			if(i == memory.length - 1) {
				break;
			}
			instr = sc.nextInt();
			i++;
		}
		System.out.println("*** Program loaded ***");
		sc.close();
	}
	
	public void loadProgramFromFile(String filename) throws java.io.FileNotFoundException {
		File f = new File(filename);
		Scanner sc = new Scanner(f);
		
		int i = 0;
		while(sc.hasNextLine() && i != memory.length - 1) {
			memory[i] = sc.nextInt();
			i++;
		}
		sc.close();
	}
	
	public void nextInstruction() {
		
		Scanner sc = new Scanner(System.in);
		instructionRegister = memory[instructionCounter];
		int currentInstr = this.getOpcode();
		
		switch (currentInstr) {
		
		case READ:
			
			int instr = sc.nextInt();
			if(instr > 9999 || instr < -9999) {
				instr = (int) Math.ceil(instr/100);
			}
			memory[this.getOperand()] = instr;
			instructionCounter++;
			break;
		
		case WRITE:
			
			System.out.printf("%+05d ", memory[this.getOperand()]);
			instructionCounter++;
			break;
		
		case LOAD:
			
			accumulator = memory[this.getOperand()];
			instructionCounter++;
			break;
		
		case STORE:
			
			memory[this.getOperand()] = accumulator;
			instructionCounter++;
			break;
		
		case ADD:
			
			accumulator += memory[this.getOperand()];
			instructionCounter++;
			break;
		
		case SUB:
			
			accumulator -= memory[this.getOperand()];
			instructionCounter++;
			break;
		
		case DIV:
			
			if(memory[this.getOperand()] != 0) {
				accumulator /= memory[this.getOperand()]; }
			else { 
			halted = true;
			dumpCore(); }
			instructionCounter++;
			break;
		
		case MOD:
			
			if(memory[this.getOperand()] != 0) {
				accumulator %= memory[this.getOperand()]; }
			instructionCounter++;
			break;
			
		case MUL:
			
			accumulator *= memory[this.getOperand()];
			instructionCounter++;
			break;
			
		case JUMP:
			
			instructionCounter = this.getOperand();
			break;
			
		case JUMPN:
			
			if(accumulator < 0) {
				instructionCounter = this.getOperand();
			} else { instructionCounter++; }
			break;
		
		case JUMPZ:
			
			if(accumulator == 0) {
				instructionCounter = this.getOperand();
			} else { instructionCounter++; }
			break;
			
		case HALT: 
			
			halted = true;
			System.out.println("*** Program terminated normally ***");
			dumpCore();
			break;
			
		default: 
			halted = true;
			dumpCore();
	}
		if(instructionCounter >= memorySize) {
			instructionCounter = 0;
		}
		if(accumulator > 9999 || accumulator < -9999) {
			accumulator %= 10000;
		}
		sc.close();
	}
	
	public boolean isHalted() {
		return halted;
	}
	
	public int getMemorySize() {
		return memorySize;
	}
	
	public int peekMemory(int address) {
		return memory[address];
	}
	
	public int getOperand() {
		return instructionRegister % 100;
	}
	
	public int getOpcode() {
		return instructionRegister / 100;
	}
	
	public int getIR() {
		return instructionRegister;
	}
	
	public int getAC() {
		return accumulator;
	}
	
	public int getIC() {
		return instructionCounter;
	}
}