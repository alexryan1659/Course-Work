package mini2;

import java.io.File;

public class Test {
	
	public static void main(String [] args) {
	
  }
}
