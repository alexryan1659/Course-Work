package mini3;

import java.util.Arrays;

import mini3.ArrayComparator;

public class Combinations {
	
	public static void main(String[] args) {
		int[] options = { 3, 2 };
		int combinations[][] = getCombinations(options);
		
		for(int[] row : combinations) {
			System.out.println(Arrays.toString(row));
		}
	}
	
	//I'm not sure how this was supposed to be done. Very confusing
	//and very poorly written assignment. At this point I'm only
	//going for as many points as possible.
	
	public static int[][] getCombinations(int[] choices) {
		int[][] combos;
		
		if(choices.length == 1) {
			combos = new int[choices[0]][choices.length];
			for(int i = 1; i != choices[0]; i++) {
				combos[i][0] = i;
			}
			return combos;
		} else {
			
			combos = getCombinations(Arrays.copyOf(choices, choices.length - 1));
			
			for(int i = 0; i != combos.length; i++) {
				for(int j = 0; j != choices.length; j++) {
					combos = Arrays.copyOf(combos, combos.length * choices[1]);
				}
			}
		}

		//Arrays.sort(combos, new ArrayComparator());
		
		return combos;

	}
}
