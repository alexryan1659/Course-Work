package hw3;

import java.util.ArrayList;

public class tests {
	public static void main(String[] args) throws java.io.FileNotFoundException {
		
		/*int[] list = AsmFileUtil.createMemoryImageFromFile("primes.asm227");
		for(int s : list) {
			System.out.println(s);
		}*/
		/*
		ArrayList<String> list =  AsmFileUtil.assembleFromFile("collatz.asm227");
		for(String s : list) {
			System.out.println(s);
		}*/
		AsmFileUtil.assembleAndWriteFile("collatz.asm227", true);
	}
}
