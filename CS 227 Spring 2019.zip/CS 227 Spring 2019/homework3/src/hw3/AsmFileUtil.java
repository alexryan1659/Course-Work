package hw3;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * A file parser utility that can read assembly language from files
 * and return generated machine code
 * @author Alex Thompson for COM S 227
 */

public class AsmFileUtil {
	
	/**
	 * A basic file reading utility for reading assembly language
	 * and outputting machine code to a file, list, or memory image
	 */
	public AsmFileUtil() {
	}
	
	/**
	 * Reads the given file containing assembly language and returns assembled
	 * machine code as a list of strings
	 * @param filename - the file to read assembly language from
	 * @return assembled machine code from the file
	 * @throws java.io.FileNotFoundException
	 */
	public static ArrayList<String> assembleFromFile(String filename) throws java.io.FileNotFoundException {
		
		File f = new File(filename);
		Scanner sc = new Scanner(f);
		ArrayList<String> program = new ArrayList<String>();
		
		while(sc.hasNextLine()) {
			program.add(sc.nextLine());
		}
		
		CS227Asm asm = new CS227Asm(program);
		sc.close();
		return asm.assemble();
	}
	
	/**
	 * Reads the given file containing assembly language and writes assembled
	 * machine code to "filename.mach227"
	 * @param filename - the file to read assembly language from
	 * @param annotated - if instruction descriptions should be included in generated file
	 * @throws java.io.FileNotFoundException
	 */
	public static void assembleAndWriteFile(String filename, boolean annotated) throws java.io.FileNotFoundException {
		
		//file to create/write to                      //filename.mach227
		File machineCode = new File(filename.substring(0, filename.indexOf(".")) + ".mach227");

		PrintWriter out = new PrintWriter(machineCode);
		
		ArrayList<String> code = assembleFromFile(filename); //file to read from
		
		if(annotated) { 
			for(String s : code) {
				out.println(s);
			}
		} else { //get just the machine code
			for(String s : code) {
				Scanner sc = new Scanner(s);
				out.println(sc.next());
				sc.close();
			}
		}
		
		out.close();
	}
	
	/**
	 * Reads the given file containing assembly language and returns a memory image
	 * of just machine code
	 * @param filename - the file to read assembly language from
	 * @return a memory image containing just machine code, with no descriptions
	 * @throws java.io.FileNotFoundException
	 */
	public static int[] createMemoryImageFromFile(String filename) throws java.io.FileNotFoundException {
		
		ArrayList<String> program = assembleFromFile(filename);
									//exclude sentinel value
		int memorySize = program.size() - 1;
		int[] image = new int[memorySize];
		
		for(int i = 0; i < image.length; i++) {
			Scanner code = new Scanner(program.get(i));
			image[i] = code.nextInt();
			code.close();
		}

		return image;
	}
}
