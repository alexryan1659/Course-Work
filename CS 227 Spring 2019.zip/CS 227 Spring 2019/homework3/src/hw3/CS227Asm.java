package hw3;

import java.util.ArrayList;
import java.util.Scanner;

import api.Instruction;
import api.SymbolTable;

/**
 * An assembler that takes a valid assembly language
 * and returns assembled machine code
 * 
 * @author Alex Thompson for COM S 227
 */
public class CS227Asm {
	
	/**Holds data values**/
	private SymbolTable data;
	
	/**Holds label values**/
	private SymbolTable labels;
	
	/**Holds instructions**/
	private ArrayList<Instruction> instructions;
	
	/**The program that data, labels, and instructions are derived from**/
	private ArrayList<String> program;
	
	/** 
	 * An assembler that takes a program and produces machine code
	 * @param program - the assembly language to create machine code
	 */
	public CS227Asm(ArrayList<String> program) {
		
		this.program = program;
		data = new SymbolTable();
		labels = new SymbolTable();
		instructions = new ArrayList<Instruction>();
	}
	
	/**
	 * Parses the specified data values in the program
	 */
	public void parseData() {
		
		//search until "labels" section is found
		for(int i = 1; !program.get(i).equals("labels:"); i++) {
			Scanner sc = new Scanner(program.get(i));
			data.add(sc.next(), sc.nextInt());
			sc.close();
		}
	}
	
	/** 
	 * Parses label values in the program
	 */
	public void parseLabels() {
		
		for(int i = program.indexOf("labels:") + 1; 
				!program.get(i).equals("instructions:"); i++) {
			
			labels.add(program.get(i));
		}
	}
	
	/**
	 * Parses instructions in the program, and assigns addresses to any labels
	 */
	public void parseInstructions() {
		
		//pos helps keep track of what address jumps should jump to
		int pos = 0;
		
		for(int i = program.indexOf("instructions:") + 1;
				i != program.size(); i++) {
			
			if(labels.containsName(program.get(i))) { //if a jump instruction
				labels.findByName(program.get(i)).setValue(pos);
				pos--;
			} else { //if not a jump
				instructions.add(new Instruction(program.get(i)));
			}
			pos++;
		}
	}
	
	/**
	 * Assigns operand values to instructions and gives proper addresses to labels
	 */
	public void setOperandValues() {
		
		for(Instruction instr : instructions) {
			
			//if instruction is a jump target, 
			if(instr.requiresJumpTarget()) {
				
				instr.setOperand(labels.findByName(instr.getOperandString()).getValue());
			//if not its an instruction and refers to a variable
			} else if(instr.requiresDataAddress()) {
				
				instr.setOperand(data.indexOf(data.findByName(instr.getOperandString()))
						+ instructions.size());
			}
		}
	}
	
	/**
	 * For jump targets, adds the label to the instruction's description
	 */
	public void addLabelAnnotations() {
		
		//...search for jump targets, get the operand as string and add to label
		for(Instruction instr : instructions) {
			if(instr.requiresJumpTarget()) {
				instructions.get(instr.getOperand()).addLabelToDescription(instr.getOperandString());
			}
		}
	}

	/** 
	 * Generates machine code from the instructions
	 * @return the machine code, as a list of strings
	 */
	public ArrayList<String> writeCode() {
		
		ArrayList<String> code = new ArrayList<String>();
		
		//instructions come first...
		for(Instruction instr : instructions) {
			code.add(instr.toString());
		}
		
		//...then the data variables
		for(int i = 0; i != data.size(); i++) {
			code.add(String.format("+%04d", data.getByIndex(i).getValue()) + " " +
					data.getByIndex(i).getName());
		}
		
		//the sentinel value
		code.add("-99999");
		
		return code;
	}
	
	/**
	 * Parses data, labels, and instructions, assigns operand values and label
	 * annotations where appropriate, and writes the machine code
	 * @return the machine code, as a list of strings
	 */
	public ArrayList<String> assemble() {
		parseData();
		parseLabels();
		parseInstructions();
		setOperandValues();
		addLabelAnnotations();
		return writeCode();
	}
	
	/**
	 * Returns data (variables) and their assigned values
	 * @return the data, and their associated values
	 */
	public SymbolTable getData() {
		return data;
	}
	
	/**
	 * Returns the labels (jumps) and their addresses; note that if instructions are not 
	 * parsed before getting, the labels will hold address 0
	 * @return the labels and their addresses
	 */
	public SymbolTable getLabels() {
		return labels;
	}
	
	/**
	 * Returns the instruction stream in the program.
	 * If instructions aren't parsed before getting, no instructions will be present
	 * @return the program's instructions
	 */
	public ArrayList<Instruction> getInstructionStream() {
		return instructions;
	}
}