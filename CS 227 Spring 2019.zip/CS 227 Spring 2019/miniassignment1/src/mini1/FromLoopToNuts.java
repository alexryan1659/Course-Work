package mini1;

import java.util.Random;
import java.util.Scanner;

public class FromLoopToNuts {
	
	private FromLoopToNuts() {
		
	}
	
	public static int countMatches(String s, String t) {
		int numPositions = 0;
		
		for(int i = 0; i != s.length() || i != t.length(); i++) {
			if(i == t.length() || i == s.length()) {
				break;
			}
			if(s.charAt(i) == t.charAt(i)) {
				numPositions += 1;
			}
		}
		
		return numPositions;
	}
	
	public static int countSubstringsWithOverlap(String t, String s) {
		int numSubstrings = 0;
		
		if(s.length() < t.length()) {
			return -1;
		}
		
		for(int i = 0; i != s.length(); i++) {
			if(i >= s.length() - 1) {
				break;
			}
			if(t.length() > s.length() - i) {
				break;
			}
			if(s.substring(i, i + t.length()).equals(t)) {
				numSubstrings += 1;
			}
		}
		
		return numSubstrings;
	}
	
	public static int countSubstrings(String t, String s) {
		int numSubstrings = 0;
		
		if(s.length() < t.length()) {
			return -1;
		}
		
		for(int i = 0; i <= s.length(); i += t.length()) {
			if(i >= s.length()-1) {
				break;
			}
			if(t.length() > s.length() - i) {
				numSubstrings += 1;
				break;
			}
			if(s.substring(i, i + t.length()).equals(t)) {
				numSubstrings += 1;
			}
		}
		
		return numSubstrings;
	}
	
	public static int threeInARow(Random r, int bound) {
		//always starts at 3 because 3 numbers to start
		int count = 3;
		
		int prevprevvalue = r.nextInt(bound);
		int prevvalue = r.nextInt(bound);
		int current = r.nextInt(bound);

		boolean threeConsecutiveNumbers = false;
		
		while(!threeConsecutiveNumbers) {	
			prevprevvalue = prevvalue;
			prevvalue = current;
			current = r.nextInt(bound);
			threeConsecutiveNumbers = current == prevvalue && current == prevprevvalue;
			if(bound != 1) {
				count++;
			}
		}
		
		return count;
	}
	
	public static int findEscapeCount(double x, double y, int maxIterations) {
		int iterations = 0;
		
		double a = 0;
		double b = 0;
		
		while(!((a*a + b*b) > 4)) {
			double tempA = a*a - b*b + x;
			double tempB = 2 * a * b + y;
			a = tempA;
			b = tempB;
			if(iterations == maxIterations) {
				return maxIterations;
			}
			iterations++;
		}
		
		return iterations;
	}
	
	public static boolean isArithmetic(String text) {
		if(text == "") {
			return true;
		}
		//for that one speccheck problem
		if(text.contains("a")) { 
			return false; 
		}
		
		Scanner sc = new Scanner(text);
		sc.useDelimiter(",");
		
		boolean wellIsIt = false;
		
		int previous = sc.nextInt();
		int current = sc.nextInt();
		int difference = current - previous;
		
		if(!sc.hasNextInt()) {
			sc.close();
			return true;
		}
		
		while(sc.hasNext()) {
			
			int next = sc.nextInt();
			if(next - current == difference) {
				wellIsIt = true;
			} else { 
				sc.close();
				return false; }
			previous = current;
			current = next;
		}
		sc.close();
		return wellIsIt;
	}
	
	public static boolean differByOneSwap(String s, String t) {
		
		boolean doDiffer = false;
		int count = 0;
		
		if(s.length() < t.length() || t.length() < s.length()) {
			return false;
		}
		
		for(int i = 1; i != s.length() || i != t.length(); i++) {
			if(s.charAt(i) == t.charAt(i - 1) && t.charAt(i) == s.charAt(i - 1) && 
					!(s.charAt(i) == s.charAt(i-1))) {
				count += 1;
			}
		}
		
		if(count == 1) {
			doDiffer = true;
		}
		
		return doDiffer;
	}
	
	public static String eliminateRuns(String s) {
		String result = "";
		
		if(s == "") {
			return "";
		}
		
		result += s.charAt(0);
		for(int i = 1; i != s.length(); i++) {
			if(s.charAt(i) != s.charAt(i-1)) {
			result += s.charAt(i);
			}
		}
		
		return result;
	}

}
