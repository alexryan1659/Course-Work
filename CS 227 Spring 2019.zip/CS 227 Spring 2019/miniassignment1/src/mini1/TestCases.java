package mini1;

import java.util.Random;
import java.util.Scanner;

import mini1.FromLoopToNuts;

public class TestCases {
	
	public static void main(String [] args) {
		Scanner sc = new Scanner(System.in);
		/*String s = "bcbc";
		String t = "abbcce"; // returns 2
		System.out.println(FromLoopToNuts.countMatches(s, t));*/
		
		//String s = "aaaaa";
		//String t = "aa";
		//System.out.println(FromLoopToNuts.countSubstrings(t, s));
		//System.out.println(s.indexOf(t));
		
		//System.out.println(FromLoopToNuts.threeInARow(new Random(), 1));
		
		//System.out.println(FromLoopToNuts.findEscapeCount(1, 0.5, 5));
		
		//System.out.println(FromLoopToNuts.isArithmetic("-2,5,12,19,26"));
				
		
		//System.out.println(FromLoopToNuts.differByOneSwap("apple", "appel"));
		
		//System.out.println(FromLoopToNuts.eliminateRuns("abbbccbbd"));
	}

}
