package hw2;

import api.Outcome;

public class CricketGameTest {
	public static void main(String [] args) {
	}
}
