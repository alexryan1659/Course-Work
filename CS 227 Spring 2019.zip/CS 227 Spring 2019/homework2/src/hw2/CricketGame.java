package hw2;

import api.Defaults;
import api.Outcome;
import static api.Outcome.*;
/** 
 * A simulation for the very-British game Cricket, where two sides can
 * "bowl" a ball and update the game based on various predefined outcomes.
 * 
 * @author Alex Thompson for COM S 227
 */

public class CricketGame {
	
	/** Maximum number of innings to play to, default 2**/
	private int maxInnings = Defaults.DEFAULT_NUM_INNINGS;
	/** How many bowls in one over, default 6**/
	private int bowlsPerOver = Defaults.DEFAULT_BOWLS_PER_OVER;
	/** Number of players on each team, default 11**/
	private int numPlayers = Defaults.DEFAULT_NUM_PLAYERS;
	/** How many overs occur in each innings, default 50**/
	private int oversPerInnings = Defaults.DEFAULT_OVERS_PER_INNINGS;
	
	/** Current innings**/
	private int innings;
	/** Current bowl count**/
	private int bowlCount;
	/** Current overs**/
	private int overs;
	/** Current players out on batting side**/
	private int playersOut;
	/** Score of side 0**/
	private int score0;
	/** Score of side 1**/
	private int score1;
	
	/** If batsman is running**/
	private boolean running;
	/** If ball is in play**/
	private boolean inPlay;
	
	/** Constructs a Cricket game using default values**/
	public CricketGame() {
	}
	
	/** Constructs a game of Cricket with specified values
	 * @param givenBowlsPerOver - bowls per over to override the default value
	 * @param givenOversPerInnings - how many overs until next innings
	 * @param givenTotalInnings - number of maximum Innings to play to,
	 *  if an odd number, it will be adjusted up to next even number to encourage fair games
	 * @param givenNumPlayers - number of players on each team**/
	public CricketGame(int givenBowlsPerOver, int givenOversPerInnings,
							int givenTotalInnings, int givenNumPlayers) {
		//if odd, adjusted up by 1, otherwise left alone
		if(!(givenTotalInnings % 2 == 0)) {
			maxInnings = givenTotalInnings += 1;
		} else { maxInnings = givenTotalInnings; }
		bowlsPerOver = givenBowlsPerOver;
		numPlayers = givenNumPlayers;
		oversPerInnings = givenOversPerInnings;
	}
	
	/** Bowls the ball once and updates the game based on the outcome
	 * @param outcome - predetermined outcome that will decide how the game continues,
	 * provided by Outcome class**/
	public void bowl(Outcome outcome) {
		//If game is ended, none of the following is checked.
		if(!this.isGameEnded()) {
			
			//certain outcomes were combined to reduce conditional checks
			
			if(outcome == NO_BALL || outcome == WIDE) {
				this.updateScores(1);
			}
			
			if(outcome == BOUNDARY_FOUR) {
				if(!inPlay && !running) {
					this.updateScores(4);
				}
				bowlCount += 1;
			}
			
			if(outcome == BOUNDARY_SIX) {
				if(!inPlay && !running) {
					this.updateScores(6);
				}
				bowlCount += 1;
			}
			
			if(outcome == WICKET || outcome == LBW || outcome == CAUGHT_FLY) {
				if(!inPlay && !running) {
					playersOut += 1;
					bowlCount += 1;
				}
			}
			
			if(outcome == HIT) {
				if(!inPlay && !running) {
					inPlay = true;
					bowlCount += 1;
				}
			}
			this.updateGame();
		}
	}
	
	/** If a run is attempted, the run ends and the player is out**/
	public void runOut() {
		if(running && inPlay && !(this.isGameEnded())) {
			playersOut += 1; 
			running = false;
			inPlay = false;
		}
		this.updateGame();
	}
	
	/** If ball is in play and a player is running, ball is no
	 * longer in play and runner stops. +1 to running team**/
	public void safe() {
		if(inPlay && !(this.isGameEnded())) {
			if(running) {
				this.updateScores(1);
				}
			inPlay = false;
			running = false;
			}
		this.updateGame();
	}
	
	/** Attempts a run, and if the method is called again, the
	 * running team gains a point, and this can be done until
	 * safe() or runOut() is called to end the run**/
	public void tryRun() {
		if(inPlay && !(this.isGameEnded())) {
			if(running) {
				this.updateScores(1);
				}
			running = true;
		}
	}
	
	/** Returns how many bowls have currently occured
	 * @return current bowl count **/
	public int getBowlCount() {
		return bowlCount;
	}
	
	/** Returns innings currently completed
	 * @return current innings**/
	public int getCompletedInnings() {
		return innings;
	}
	
	/** Returns current players out this innings
	 * @return players out**/
	public int getOuts() {
		return playersOut;
	}
	
	/** Returns current overs this innings
	 * @return current overs**/
	public int getOverCount() {
		return overs;
	}
	
	/** Returns the score of side0 or side1
	 * @param battingSide - whether the score returned should be the batting side or not
	 * @return the score of either the side batting, or not**/
	public int getScore(boolean battingSide) {
		if(battingSide == true) {
			if(this.whichSideIsBatting() == 0) {
				return score0;
			} 
			if(this.whichSideIsBatting() == 1) {
				return score1;
			}
		}
		if(battingSide == false) {
			if(this.whichSideIsBatting() == 0) {
				return score1;
			}
			if(this.whichSideIsBatting() == 1) {
				return score0;
			}
		}
		//only to fix compiling issue
		return 0; 
	}
	
	/** Returns the side currently batting, 0 = side0 and 1 = side1
	 * @return the side batting**/
	public int whichSideIsBatting() {
		return innings % 2;
	}
	
	/** Returns whether the game is ended, if it is, many methods cease working
	 * @return whether the game is ended or not**/
	public boolean isGameEnded() {
		//When innings reaches maximum, or side1 is 
		//winning second to last innings, game ends.
		if(innings >= maxInnings  || (score1 > score0 && innings == maxInnings-1)) {
			if(!inPlay && !running) {
				return true; }
		}
		return false;
	}
	
	/** Returns whether ball is in play or not
	 * @return if the ball is currently in play**/
	public boolean isInPlay() {
		return inPlay;
	}
	
	/** Returns whether a player is running or not
	 * @return if a player is running**/
	public boolean isRunning() {
		return running;
	}
	
	/** Helper method to simplify adding score to either team
	 * @params points - points to add to batting team**/
	private void updateScores(int points) {
		if(this.whichSideIsBatting() == 0) {
			score0 += points; } else { score1 += points; }
	}
	
	/** Helper method to update overs and innings**/
	private void updateGame() {
		if (bowlCount == bowlsPerOver) {
			overs += 1;
			bowlCount = 0;
		}
		//Overs equals overs per innings OR at least one player left, AND ball is not in play
		if ((overs == oversPerInnings || playersOut == numPlayers-1) && (!inPlay && !running)) {
			innings += 1; 
			overs = 0;
			playersOut = 0;
			bowlCount = 0;
		}
	}
}