package hw1;

/** A simulation for an UberDriver that can simulate a typical day of
 * picking up passengers driving them around and dropping them off, 
 * as well as tallying credits and profit.
 * @author Alex Thompson for COM S 227 **/
public class UberDriver {
	
	/**Ensures passenger count does not exceed 4**/
	public static final int MAX_PASSENGERS = 4;
	/**Factors into determining profit (0.5 multiplier)**/
	public static final double OPERATING_COST = 0.5;
	
	/**Number of passengers**/
	private int numPassengers;
	/**Total miles added up**/
	private int milesDriven;
	/**Total minutes added up**/
	private int minutesDriven;
	/**Total credits added up**/
	private double totalCredits;
	/**Rate that factors into calculating credits for miles driven**/
	private double perMileRate;
	/**Rate that factors into calculating credits for minutes driven**/
	private double perMinuteRate;
	
	/** Creates an example of an UberDriver that can
	 * pick up and drop off passengers, and simulate earnings.
	 * Earnings are calculated based on rates. 
	 * @param givenPerMileRate The multiplier used to determine earnings based on miles driven
	 * @param givenPerMinuteRate The multiplier used to determine earnings based on minutes driven**/
	public UberDriver(double givenPerMileRate, double givenPerMinuteRate) {
		perMileRate = givenPerMileRate;
		perMinuteRate = givenPerMinuteRate;
	}
	
	/** Returns total miles driven by the Uber.
	 * @return Total miles driven **/
	public int getTotalMiles() {
		return milesDriven;
	}
	
	/** Returns total minutes the Uber has driven for.
	 * @return Total minutes driven **/
	public int getTotalMinutes() {
		return minutesDriven;
	}
	
	/** Returns total passengers in the car at the time.
	 * @return Current number of passengers **/
	public int getPassengerCount() {
		return numPassengers;
	}
	
	/** Returns total credits the Uber has earned.
	 * @return Total credits from driving **/
	public double getTotalCredits() {
		return totalCredits;
	}
	
	/** Returns profit the Uber has earned, after accounting for operating cost.
	 * @return Total profit from subtracting total credits 
	 by miles driven times operating cost **/
	public double getProfit() {
		return totalCredits - (milesDriven * OPERATING_COST);
	}
	
	/** Returns average profit over an hour
	 * @return Average profit per hour **/
	public double getAverageProfitPerHour() {
		return 60 * (this.getProfit() / minutesDriven);
	}
	
	/** Drives the Uber for the given number of miles for the given number of minutes,
	 * racking up milesDriven, minutesDriven, and adding to the credits.
	 * @param miles The miles the uber drives for
	 * @param minutes The minutes the uber drives **/
	public void drive(int miles, int minutes) {
		milesDriven += miles;
		minutesDriven += minutes;
		//Adds to the credits: ((miles*rate)+(minutes*rate))*passengercount
		totalCredits += ((miles * perMileRate) + (minutes * perMinuteRate)) * numPassengers;
	}
	
	/** Drives for the given number of miles at the given speed.
	 * @param miles Miles that the uber drives for
	 * @param averageSpeed Average speed (in miles per hour) the uber drives at, 
	 * used to calculate credits and minutes driven**/
	public void driveAtSpeed(int miles, double averageSpeed) {
		milesDriven += miles;
		minutesDriven += Math.round((60 * (miles / averageSpeed)));
		//Adds to the credits: ((miles*rate)+(minutes*rate))*passengercount
		totalCredits += ((miles * perMileRate) + (Math.round((60 * (miles / averageSpeed))) * perMinuteRate)) * numPassengers;
	}
	
	/** Simulates "waiting around" where the Uber isn't doing anything for the given time.
	 * Increases minutes as well as credits, if passengers present.
	 * @param minutes The time in minutes the Uber waits around for **/
	public void waitAround(int minutes) {
		minutesDriven += minutes;
		totalCredits += (minutes * perMinuteRate) * numPassengers;
	}
	
	/** Drops off a passenger, subtracting 1 from the passenger count,
	 * but never dropping below zero.
	 * (passengers factor into the credits earned)**/
	public void dropOff() {
		numPassengers = Math.max(numPassengers -= 1, 0);
	}
	
	/** Picks up a passenger, adding 1 to the passenger count,
	 * but never exceeding MAX_PASSENGERS (4).
	 * (passengers factor into the credits earned)**/
	public void pickUp() {
		numPassengers = Math.min(numPassengers += 1, MAX_PASSENGERS);
	}
}