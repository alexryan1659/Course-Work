package hw1;

public class UberDriverTest {
	
	//Testing ground I used for various cases
	public static void main(String[] args) {
		UberDriver d = new UberDriver(1.00, 0.20);
		System.out.println(d.getProfit());
		System.out.println(d.getAverageProfitPerHour());
		System.out.println(d.getPassengerCount());
		System.out.println(d.getTotalMiles());
		System.out.println(d.getTotalMinutes());
	}
}
