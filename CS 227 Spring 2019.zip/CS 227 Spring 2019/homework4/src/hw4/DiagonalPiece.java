package hw4;

import api.Cell;
import api.Icon;
import api.Position;

/** 
 * Class to generate a diagonal-shaped piece
 * @author Alex Thompson for COM S 227
 */
public class DiagonalPiece extends AbstractPiece {

	/** A diagonal-shaped piece 
	 * @param givenPosition - the position to set this piece to
	 * @param icons - an array of colored this piece should use (2 needed)
	 */
	public DiagonalPiece(Position givenPosition, Icon[] icons) {
		super();
		super.setPosition(givenPosition);
		Cell[] cells = new Cell[2];
		if(icons.length != 2) {
			throw new IllegalArgumentException();
		} else {
			cells[0] = new Cell(icons[0], new Position(0, 0));
			cells[1] = new Cell(icons[1], new Position(1, 1));
		}
		super.setCells(cells);
	}
	
	@Override
	public void transform() {
		Cell[] c = super.getCells();
		if(c[0].getCol() == 0) {
			c[0].setCol(c[0].getCol()+1);
			c[1].setCol(c[1].getCol()-1);
		} else {
			c[0].setCol(c[0].getCol()-1);
			c[1].setCol(c[1].getCol()+1);
		}
		super.setCells(c);
	}
	
	@Override
	public void cycle() {
		Cell[] c = super.getCells();
		
		Cell temp = new Cell(c[1].getIcon(), super.getPosition());
		c[1].setIcon(c[0].getIcon());
		c[0].setIcon(temp.getIcon());
		super.setCells(c);
	}
}
