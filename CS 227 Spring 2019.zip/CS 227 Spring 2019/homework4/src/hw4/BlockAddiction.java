package hw4;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import api.AbstractGame;
import api.Generator;
import api.Icon;
import api.Position;

/**
 * Class for the Tetris-style game BlockAddiction! extending AbstractGame
 * @author Alex Thompson for COM S 227
 */
public class BlockAddiction extends AbstractGame {
	
	/**
	 * An instance of BlockAddiction! using the given height and
	 * width to construct the board, generator for randomness,
	 * and number of prefilled rows for challenge
	 * @param height - height of the game board
	 * @param width - width of the game board
	 * @param gen - generator to use for randomness
	 * @param preFillRows - number of rows to fill, must be greater than 0 for effect
	 */
	public BlockAddiction(int height, int width, Generator gen, int preFillRows) {
		super(height, width, gen);
		
		//fill in rows checkerboard-style, so long as # of rows is appropriate
		//different scenarios whether width is even/odd, to prevent errors
		if(preFillRows > 0 && !(preFillRows >= height) ) {
			for(int r = height-1; r != (height-preFillRows)-1; r--) {
				if(width % 2 == 0) {
					if(r % 2 == 0) {
						for(int c = width-1; c != -1; c -= 2) {
							super.setBlock(r, c, gen.randomIcon());
						}
					} else {
						for(int c = width-2; c != -2; c -= 2) {
							super.setBlock(r, c, gen.randomIcon());
						}
					}
				} else {
					if(r % 2 == 0) {
						for(int c = width-1; c != -2; c -= 2) {
							super.setBlock(r, c, gen.randomIcon());
						}
					} else {
						for(int c = width-2; c != -1; c -= 2) {
							super.setBlock(r, c, gen.randomIcon());
						}
					}
				}
			}
		}
	}

	/**
	 * An instance of BlockAddiction! using the given height and
	 * width to construct the board, and generator for randomness.
	 * No rows are filled for this instance
	 * @param height - height of the game board
	 * @param width - width of the game board
	 * @param gen - generator to use for randomness
	 */
	public BlockAddiction(int height, int width, Generator gen) {
		super(height, width, gen);
	}
	
	/**
	 * Returns a list of positions to be collapsed on the board
	 * @return pos - list of positions that will be collapsed
	 */
	public List<Position> determinePositionsToCollapse() {
		
		List<Position> positions = new ArrayList<Position>();
		
		for (int row = 0; row != getHeight(); row++) {
	      for (int col = 0; col != getWidth(); col++) {
	    	  List<Position> set = getNeighbors(super.getIcon(row, col), row, col);
	    	  if(set.size() >= 3) {
	    		  for(Position p : set) {
	    			  positions.add(p);
	    		  }
	    	  }
	      	}
	    } 
		
		//remove duplicates
		List<Position> pos = new ArrayList<Position>();
		for(Position p : positions) {
			if(!pos.contains(p)) {
				pos.add(p);
			}
		}

	    Collections.sort(pos);
	    return pos;
	}
	
	/**
	 * Helper method to get the matching neighboring positions
	 * @param icon - the icon to check neighbors for
	 * @param r - row to find neighbors
	 * @param c - column to find neighbors
	 * @return positions - list of positions who have any number of matching neighbors
	 */
	private List<Position> getNeighbors(Icon icon, int r, int c) {
		List<Position> positions = new ArrayList<Position>();
		positions.add(new Position(r, c));
		
		//yes, its sloppy, but it accounts for everything
		
		if(icon != null) {
		if(r == 0 && c == 0) {
			if(icon.matches(super.getIcon(r, c+1))) { positions.add(new Position(r, c+1)); }
			if(icon.matches(super.getIcon(r+1, c))) { positions.add(new Position(r+1, c)); }
			return positions;
		} else if (r == getHeight()-1 && c == 0) {
			if(icon.matches(super.getIcon(r, c+1))) { positions.add(new Position(r, c+1)); }
			if(icon.matches(super.getIcon(r-1, c))) { positions.add(new Position(r-1, c)); }
			return positions;
		} else if(r == 0 && c == getWidth()-1) {
			if(icon.matches(super.getIcon(r, c-1))) { positions.add(new Position(r, c-1)); }
			if(icon.matches(super.getIcon(r+1, c))) { positions.add(new Position(r+1, c)); }
			return positions;
		} else if(r == getHeight()-1 && c == getWidth()-1) {
			if(icon.matches(super.getIcon(r-1, c))) { positions.add(new Position(r-1, c)); }
			if(icon.matches(super.getIcon(r, c-1))) { positions.add(new Position(r, c-1)); }
			return positions;
		} else if(r == 0) {
			if(icon.matches(super.getIcon(r, c-1))) { positions.add(new Position(r, c-1)); }
			if(icon.matches(super.getIcon(r, c+1))) { positions.add(new Position(r, c+1)); }
			if(icon.matches(super.getIcon(r+1, c))) { positions.add(new Position(r+1, c)); }
			return positions;
		} else if(r == getHeight()-1) {
			if(icon.matches(super.getIcon(r, c-1))) { positions.add(new Position(r, c-1)); }
			if(icon.matches(super.getIcon(r, c+1))) { positions.add(new Position(r, c+1)); }
			if(icon.matches(super.getIcon(r-1, c))) { positions.add(new Position(r-1, c)); }
			return positions;
		} else if(c == 0) {
			if(icon.matches(super.getIcon(r-1, c))) { positions.add(new Position(r-1, c)); }
			if(icon.matches(super.getIcon(r, c+1))) { positions.add(new Position(r, c+1)); }
			if(icon.matches(super.getIcon(r+1, c))) { positions.add(new Position(r+1, c)); }
			return positions;
		} else if(c == getWidth()-1) {
			if(icon.matches(super.getIcon(r-1, c))) { positions.add(new Position(r-1, c)); }
			if(icon.matches(super.getIcon(r, c-1))) { positions.add(new Position(r, c-1)); }
			if(icon.matches(super.getIcon(r+1, c))) { positions.add(new Position(r+1, c)); }
			return positions;
		} else {
			if(icon.matches(super.getIcon(r-1, c))) { positions.add(new Position(r-1, c)); } 
			if(icon.matches(super.getIcon(r, c-1))) { positions.add(new Position(r, c-1)); } 
			if(icon.matches(super.getIcon(r, c+1))) { positions.add(new Position(r, c+1)); } 
			if(icon.matches(super.getIcon(r+1, c))) { positions.add(new Position(r+1, c)); } 
			return positions;
			}
		}
		return positions;
	}
}
