package hw4;

import api.Cell;
import api.Icon;
import api.Position;

/**
 * Class to generate an L-shaped piece
 * @author Alex Thompson for COM S 227
 */
public class LPiece extends AbstractPiece{

	/** An L-shaped piece 
	 * @param givenPosition - the position to set this piece to
	 * @param icons - an array of colored icons this piece should use (4 needed)
	 */
	public LPiece(Position givenPosition, Icon[] icons) {
		super();
		super.setPosition(givenPosition);
		Cell[] cells = new Cell[4];
		if(icons.length != 4) {
			throw new IllegalArgumentException();
		} else {
			cells[0] = new Cell(icons[0], new Position(0,0));
			cells[1] = new Cell(icons[1], new Position(0,1));
			cells[2] = new Cell(icons[2], new Position(1,1));
			cells[3] = new Cell(icons[3], new Position(2,1));
		}
		super.setCells(cells);
	}
	
	@Override
	public void transform() {
		Cell[] c = super.getCells();
		if(c[0].getCol() == 0) {
			c[0].setCol(c[0].getCol() + 2);
		} else {
			c[0].setCol(c[0].getCol() - 2); }
		super.setCells(c);
	}
	
	@Override
	public void cycle() {
		
		Cell[] c = super.getCells();
		Cell temp = new Cell(c[3].getIcon(), super.getPosition());
		
		c[3].setIcon(c[2].getIcon());
		c[2].setIcon(c[1].getIcon());
		c[1].setIcon(c[0].getIcon());
		c[0].setIcon(temp.getIcon());
		super.setCells(c);
		
	}
}
