package hw4;

import api.Cell;
import api.Icon;
import api.Position;

/** 
 * Class to generate a corner piece
 * @author Alex Thompson for COM S 227
 */
public class CornerPiece extends AbstractPiece {
	
	/** Sequence for this corner piece */
	private static final Position[] sequence = {
		new Position(0,0),
		new Position(0,1),
		new Position(1,1),
		new Position(1,0)
	};
	/** Keeps track of what transform this corner piece is on */
	private int transformSequence = 1;

	/** A corner piece 
	 * @param givenPosition - the position to set this piece to
	 * @param icons - an array of colored icons this piece should use (3 needed)
	 */
	public CornerPiece(Position givenPosition, Icon[] icons) {
		super();
		Cell[] cells = new Cell[3];
		if(icons.length != 3) {
			throw new IllegalArgumentException();
		} else {
			cells[0] = new Cell(icons[0], new Position(0, 0));
			cells[1] = new Cell(icons[1], new Position(1, 0));
			cells[2] = new Cell(icons[2], new Position(1, 1));
		}
		super.setCells(cells);
		super.setPosition(givenPosition);
	}
	
	@Override
	public void transform() {
		Cell[] cells = super.getCells();
		
		cells[2].setPosition(new Position(cells[1].getRow(), cells[1].getCol()));
		cells[1].setPosition(new Position(cells[0].getRow(), cells[0].getCol()));
		cells[0].setPosition(sequence[transformSequence]);
		
		super.setCells(cells);
		transformSequence++;
		if(transformSequence == 4) { 
			transformSequence = 0; 
		}
	}
	
	@Override
	public void cycle() {
		Cell[] c = super.getCells();
		
		Cell temp = new Cell(c[2].getIcon(), super.getPosition());
		c[2].setIcon(c[1].getIcon());
		c[1].setIcon(c[0].getIcon());
		c[0].setIcon(temp.getIcon());
		
		super.setCells(c);
	}
}
