package hw4;

import api.Cell;
import api.Icon;
import api.Position;

/**
 * Class to generate an I-shaped piece
 * @author Alex Thompson for COM S 227
 */
public class IPiece extends AbstractPiece{

	/** An I-shaped piece. This piece does not transform
	 * @param givenPosition - the position to set this piece to
	 * @param icons - an array of colored icons this piece should use (3 needed)
	 */
	public IPiece(Position givenPosition, Icon[] icons) {
		super();
		Cell[] cells = new Cell[3];
		if(icons.length != 3) {
			throw new IllegalArgumentException();
		} else {
			cells[0] = new Cell(icons[0], new Position(0, 1));
			cells[1] = new Cell(icons[1], new Position(1, 1));
			cells[2] = new Cell(icons[2], new Position(2, 1));
		}
		super.setCells(cells);
		super.setPosition(givenPosition);
	}
	
	@Override
	public void cycle() {
		Cell[] c = super.getCells();
		Cell temp = new Cell(c[2].getIcon(), super.getPosition());
		
		c[2].setIcon(c[1].getIcon());
		c[1].setIcon(c[0].getIcon());
		c[0].setIcon(temp.getIcon());
		super.setCells(c);
	}
	
	@Override
	public void transform() {
		//does not transform
	}
}
