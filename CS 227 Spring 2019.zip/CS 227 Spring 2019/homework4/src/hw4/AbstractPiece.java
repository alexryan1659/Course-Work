package hw4;

import api.Cell;
import api.Icon;
import api.Piece;
import api.Position;

/**
 * Superclass to represent a piece for BlockAddiction!
 * @author Alex Thompson for COM S 227
 */
public abstract class AbstractPiece implements Piece {
	
	/** The cells of a piece */
	private Cell[] cells;
	/** The position of a piece bounded by the upper-left corner of its bounding box */
	private Position position;
	
	/**
	 * Object representing 5 possible pieces:
	 * LPiece, IPiece, CornerPiece, DiagonalPiece, and SnakePiece
	 */
	protected AbstractPiece() {
	}
	
	/** Returns a deep copy of this object having the correct runtime type*/
	public AbstractPiece clone() {
	    try
	    {
	      AbstractPiece s = (AbstractPiece) super.clone();
     
	      s.cells = new Cell[cells.length];
	      for (int i = 0; i < cells.length; ++i)
	      {
	        s.cells[i] = new Cell(cells[i]);
	      }
	      return s;
	    }
	    catch (CloneNotSupportedException e)
	    {
	      return null;
	    }    
	  }

	@Override
	public Position getPosition() {
		return position;
	}

	@Override
	public  Cell[] getCells() {
		Cell[] copy = new Cell[cells.length];
		
		for(int i = 0; i != cells.length; i++) {
			copy[i] = new Cell(cells[i]);
		}
	    return copy;
	}

	@Override
	public Cell[] getCellsAbsolute() {

		Cell[] abs = new Cell[cells.length];
		
		for(int i = 0; i != abs.length; i++) {
			int row = cells[i].getRow() + position.row();
		    int col = cells[i].getCol() + position.col();
		    Icon b = cells[i].getIcon();
		    abs[i] = new Cell(b, new Position(row, col));
		}
		
		return abs;
	}

	@Override
	public void setCells(Cell[] givenCells) {
		
		Cell[] copy = new Cell[givenCells.length];
		for(int i = 0; i != copy.length; i++) {
			copy[i] = new Cell(givenCells[i]);
		}
		cells = copy;
	}

	@Override
	public void shiftDown() {
		position = new Position(position.row() + 1, position.col());
	}

	@Override
	public void shiftLeft() {
		position = new Position(position.row(), position.col() - 1);
	}
	
	@Override
	public void shiftRight() {
		position = new Position(position.row(), position.col() + 1);
	}

	@Override
	public abstract void transform();
	
	@Override
	public abstract void cycle();
	
	/** Sets the position within AbstractPiece
	 * @param pos - what position to be set to
	 */
	protected void setPosition(Position pos) {
		position = pos;
	}
}
