package hw4;

import api.Cell;
import api.Icon;
import api.Position;

/**
 * Class to generate a snake piece
 * @author Alex Thompson for COM S 227
 */
public class SnakePiece extends AbstractPiece{
	
	/** The sequence the snakepiece transformation follows */
	private static final Position[] sequence = {
			new Position(0, 0),
			new Position(0, 1),
			new Position(0, 2),
			new Position(1, 2),
			new Position(1, 1),
			new Position(1, 0),
			new Position(2, 0),
			new Position(2, 1),
			new Position(2, 2),
			new Position(1, 2),
			new Position(1, 1),
			new Position(1, 0)
	};
	/** Keeps track of what transform the snake piece is on */
	private int transformSequence = 1;
	
	/** A snake piece, going through multiple transformations
	 * @param givenPosition - the position to set this piece to
	 * @param icons - an array of colored icons this piece should use (4 needed)
	 */
	public SnakePiece(Position givenPosition, Icon[] icons) {
		super();
		Cell[] cells = new Cell[4];
		if(icons.length != 4) {
			throw new IllegalArgumentException();
		} else {
			cells[0] = new Cell(icons[0], new Position(0, 0));
			cells[1] = new Cell(icons[1], new Position(1, 0));
			cells[2] = new Cell(icons[2], new Position(1, 1));
			cells[3] = new Cell(icons[3], new Position(1, 2));
		}
		super.setCells(cells);
		super.setPosition(givenPosition);
	}
	
	@Override
	public void transform() {
		Cell[] cells = super.getCells();
		
		cells[3].setPosition(new Position(cells[2].getRow(), cells[2].getCol()));
		cells[2].setPosition(new Position(cells[1].getRow(), cells[1].getCol()));
		cells[1].setPosition(new Position(cells[0].getRow(), cells[0].getCol()));
		cells[0].setPosition(sequence[transformSequence]);
		
		super.setCells(cells);
		transformSequence++;
		if(transformSequence == 12) { 
			transformSequence = 0; 
		}
	}
	
	@Override
	public void cycle() {
		Cell[] c = super.getCells();
		Cell temp = new Cell(c[3].getIcon(), super.getPosition());
		
		c[3].setIcon(c[2].getIcon());
		c[2].setIcon(c[1].getIcon());
		c[1].setIcon(c[0].getIcon());
		c[0].setIcon(temp.getIcon());
		super.setCells(c);
	}

}
