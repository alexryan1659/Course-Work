import java.util.Random;

/**
 * A class representing a Node in a treap
 * @author Alex Thompson for COM S 311
 */
public class Node {
	
	Interval interv;
	int priority;
	int iMax;
	Node parent;
	Node left;
	Node right;
	
	int height;
	
	/**
	 * Creates a new Node that holds the given interval and
	 * a randomly generated priority.
	 * @param i - the interval associated with this node
	 */
	public Node(Interval i) {
		interv = i;
		priority = new Random().nextInt(Integer.MAX_VALUE);
	}
	
	//Used for testing only
	/*
	public Node(Interval i, int priority) {
		interv = i;
		this.priority = priority;
	}
	*/
	
	
	/**
	 * Returns the interval of this node.
	 * @return the interval of this node
	 */
	public Interval getInterv() {
		return interv;
	}
	
	/**
	 * Returns the priority generated for this node.
	 * @return the priority of this node
	 */
	public int getPriority() {
		return priority;
	}
	
	/**
	 * Returns the largest interval in the subtree rooted at this nood
	 * @return the largest interval in the subtree
	 */
	public int getIMax() {
		return iMax;
	}
	
	/**
	 * Returns the parent node of this node (a null parent node means
	 * this node is the root)
	 * @return the parent of this node
	 */
	public Node getParent() {
		return parent;
	}
	
	/**
	 * Returns the left child of this node
	 * @return the left child node of this node
	 */
	public Node getLeft() {
		return left;
	}
	
	/**
	 * Returns the right child of this node
	 * @return the left child node of this node
	 */
	public Node getRight() {
		return right;
	}
	
	@Override
	public String toString() {
		if(interv == null || this == null) {
			return null;
		} else {
		return "["+iMax+","+priority+","+interv.toString()+"]";
		}
	}
}