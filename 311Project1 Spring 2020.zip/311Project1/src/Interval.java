/**
 * A class representing intervals
 * @author Alex Thompson for COM S 311
 */
public class Interval {
	
	int low;
	int high;
	
	/**
	 * An interval represented by high and low end points
	 * @param low - low end point
	 * @param high - high end point
	 */
	public Interval(int low, int high) {
		this.low = low;
		this.high = high;
	}
	
	/**
	 * Returns the low point of this interval
	 * @return - low end point
	 */
	public int getLow() {
		return low;
	}
	
	/**
	 * Returns the high point of this interval
	 * @return - high end point
	 */
	public int getHigh() {
		return high;
	}
	
	@Override
	public String toString() {
		return low + " to " + high;
	}
}