import java.util.ArrayList;
import java.util.List;

/**
 * A class representing a Treap that holds intervals
 * @author Alex Thompson for COM S 311
 */
public class IntervalTreap {
	
	Node root;
	int size;
	int height;
	
	/**
	 * Creates a new interval treap with no nodes and size 0.
	 */
	public IntervalTreap() {
		root = null;
		size = 0;
		height = 0;
	}
	
	/**
	 * Inserts Node z containing an Interval into this treap.
	 * @param z - node to be inserted
	 */
	public void intervalInsert(Node z) {
		//Setup
		z.iMax = z.interv.high;
		
		//Phase 1
		Node x = root;
		Node y = null;
		
		while(x != null) {
			y = x;
			x.iMax = Math.max(z.iMax, x.iMax);
			z.height++;
			if(z.interv.low < x.interv.low) {
				x = x.left;
			} else {
				x = x.right;
			}
		}
		
		//Phase 2
		z.parent = y;
		if(y == null) {
			root = z;
			size++;
			return;
		} else if(z.interv.low < y.interv.low) {
			y.left = z;
		} else {
			y.right = z;
		}
		while(z.parent != null && z.priority <= z.parent.priority) {
			if(z.parent.right == z) {
				LeftRotate(z.parent);
				z.height--;
			} else {
				RightRotate(z.parent);
				z.height--;
			}
		}
		size++;
		height = Math.max(z.height, height);
	}
	
	/**
	 * Deletes Node z from this treap.
	 * @param z - node to be deleted
	 */
	public void intervalDelete(Node z) {
		
		//Node x represents the replacement for z
		Node x = null;
		
		if(z.left == null) {
			if(z.right == null) {
				x = z.parent;
			} else {
				x = z.right;
			}
			Transplant(z, z.right);
		} else if(z.right == null) {
			Transplant(z, z.left);
			x = z.left;
		} else {
			Node y = Minimum(z.right);
			if(y.parent != z) {
				Transplant(y, y.right);
				y.right = z.right;
				y.right.parent = y;
			}
			Transplant(z, y);
			y.left = z.left;
			y.left.parent = y;
			x = y;
		}
		
		//run a path from replacement x up to the root, updating iMax fields
		while(x != null) {
			if(x.left == null && x.right == null) {
				x.iMax = x.interv.high;
			} else if(x.right == null && x.left != null) {
				x.iMax = Math.max(x.interv.high, x.left.iMax);
			} else if(x.left == null && x.right != null) {
				x.iMax = Math.max(x.interv.high, x.right.iMax);
			} else {
				x.iMax = Math.max(x.interv.high, Math.max(x.left.iMax, x.right.iMax));
			}
			x = x.parent;
		}
		
		size--;
	}
	
	/**
	 * Returns a node x such that the interval i overlaps the interval at node x.
	 * Returns null if no such node can be found.
	 * @param i - interval to search
	 * @return reference to a node with overlapping interval i
	 */
	public Node intervalSearch(Interval i) {
		Node x = root;
		while(x != null && !(i.low <= x.interv.high && i.high >= x.interv.low)) {
			if(x.left != null && x.left.iMax >= i.low) {
				x = x.left;
			} else {
				x = x.right;
			}
		}
		return x;
	}
	
	///////////
	//Queries//
	///////////
	
	/**
	 * Returns the root of this interval treap.
	 * @return Node - the root of this interval treap
	 */
	public Node getRoot() {
		return root;
	}
	
	/**
	 * Returns the size (number of nodes) of this treap
	 * @return int - the number of nodes in the treap
	 */
	public int getSize() {
		return size;
	}
	
	/**
	 * Returns the height of this treap
	 * @return int - the height of the treap
	 */
	public int getHeight() {
		return height;
	}
	
	
	////////////////////////
	//Extra Credit Methods//
	////////////////////////
	
	
	/**
	 * Searches the treap for a node with interval end points equal to i's end points
	 * @param i - interval to search for
	 * @return reference to a node with interval i's end points
	 */
	public Node intervalSearchExactly(Interval i) {
		Node y = root;
		while(y.interv.low != i.low && y.interv.high != i.high) {
			if(y.left != null && i.low < y.interv.low) {
				y = y.left;
			} else if(y.right != null && i.high < y.interv.high) {
				y = y.right;
			}
		}
		return y;
	}
	
	/**
	 * Returns a list with all intervals that overlap the interval i in the treap.
	 * @param i - interval to search for
	 * @return list of all intervals overlapping i in the treap
	 */
	public List<Interval> overlappingIntervals(Interval i) {
		ArrayList<Interval> a = new ArrayList<>();
		
		//runs in O(n)
		
		Node x = Minimum(root);
		for(int j = 0; j != size; j++) {
			if((i.low <= x.interv.high && i.high >= x.interv.low)) {
				a.add(x.interv);
			}
			x = Successor(x);
		}
		return a;
	}
	
	
	//////////////////
	//Helper Methods//
	//////////////////
	
	
	/**
	 * Helper method that performs a right rotation on a subtree rooted at t,
	 * in order to maintain min-heap property of a treap. Runs in constant 
	 * time as only pointers are updated
	 * @param t - root of subtree to be rotated right
	 */
	public void LeftRotate(Node t) {
		
		Node y = t.right;
		t.right = y.left;
		if(y.left != null) {
			y.left.parent = t;
		}
		y.parent = t.parent;
		if(t.parent == null) {
			root = y;
		} else if(t == t.parent.left) {
			t.parent.left = y;
		} else {
			t.parent.right = y;
		}
		y.left = t;
		t.parent = y;
		
		//Update iMax fields
		if(t.left == null && t.right == null) {
			t.iMax = t.interv.high;
		} else if(t.right == null && t.left != null) {
			t.iMax = Math.max(t.interv.high, t.left.iMax);
		} else if(t.left == null && t.right != null) {
			t.iMax = Math.max(t.interv.high, t.right.iMax);
		} else {
			t.iMax = Math.max(t.interv.high, Math.max(t.left.iMax, t.right.iMax));
		}
	}
	
	
	/**
	 * Helper method that performs a right rotation on a subtree rooted at t,
	 * in order to maintain min-heap property of a treap. Runs in constant 
	 * time as only pointers are updated
	 * @param t - root of subtree to be rotated right
	 */
	public void RightRotate(Node t) {
		
		Node y = t.left;
		t.left = y.right;
		if(y.right != null) {
			y.right.parent = t;
		}
		y.parent = t.parent;
		if(t.parent == null) {
			root = y;
		} else if(t == t.parent.left) {
			t.parent.left = y;
		} else {
			t.parent.right = y;
		}
		y.right = t;
		t.parent = y;
		
		//Update iMax fields
		if(t.left == null && t.right == null) {
			t.iMax = t.interv.high;
		} else if(t.right == null && t.left != null) {
			t.iMax = Math.max(t.interv.high, t.left.iMax);
		} else if(t.left == null && t.right != null) {
			t.iMax = Math.max(t.interv.high, t.right.iMax);
		} else {
			t.iMax = Math.max(t.interv.high, Math.max(t.left.iMax, t.right.iMax));
		}
	}
	
	
	/**
	 * Performs a transplant on a subtree as seen in lecture. Only updates pointers,
	 * so runs in constant time.
	 * @param u
	 * @param v
	 */
	private void Transplant(Node u, Node v) {
		if(u.parent == null) {
			root = v;
		} else if(u == u.parent.left) {
			u.parent.left = v;
		} else {
			u.parent.right = v;
		}
		if(v != null) {
			v.parent = u.parent;
		}
	}
	
	/**
	 * Testing method to find the Minimum interval in a subtree rooted
	 * at node x. Mainly used in other testing methods like Successpr and InOrder.
	 * @param x - Node to find Minimum of
	 * @return Node that is the minimum of the subtree rooted at x
	 */
	private Node Minimum(Node x) {
		while(x.left != null) {
			x = x.left;
		}
		return x;
	}
	
	/**
	 * Testing method that finds the successor of a node x.
	 * @param x - node to find the successor of
	 * @return Node that is the successor of x
	 */
	private Node Successor(Node x) {
		if(x.right != null) {
			return Minimum(x.right);
		}
		Node y = x.parent;
		while(y != null && x == y.right) {
			x = y;
			y = y.parent;
		}
		return y;
	}
	
	/**
	 * Testing method that performs an InOrder BST traversal
	 */
	public void InOrder() {
		Node x = Minimum(root);
		for(int i = 0; i != size; i++) {
			System.out.println(x);
			x = Successor(x);
		}
	}
}