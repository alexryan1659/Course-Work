#include<stdlib.h>
#include<string.h>
#include"LinkedList.h"

listptr createList() {
	listptr l = malloc(sizeof(list));
	if(l == NULL) { return NULL;}
	l->head = malloc(sizeof(node));
	if(l->head == NULL) { free(l); return NULL;}
	l->head->next = NULL;
	l->head->data = NULL;
	l->length = 0;
	return l;
}

int add(listptr lst, void* data, char* name) {

	nodeptr new = malloc(sizeof(node));
	if(new == NULL) { free(new); return 0; }

	new->data = data;
	new->name = malloc(strlen(name)+1);
	strcpy(new->name, name);
	nodeptr cur = lst->head;

	if(lst->head->next == NULL) {
		lst->head->next = new;
		lst->head->name = "";
	} else {
		while(cur->next != NULL) {
			cur = cur->next;
		}
		cur->next = new;
	}
	lst->length++;

	return 1;
}

void* searchByName(listptr lst, char* name) {

	if(name == NULL) {
		return NULL;
	}
	nodeptr cur = lst->head->next;

	for(int i = 0; i != lst->length; i++) {
		if(strcmp(cur->name, name) == 0) {
			//printf("%s\n", cur->name);
			return cur->data;
		}
		cur = cur->next;
	}

	return NULL;
}

void* getByIndex(listptr lst, int index) {
	if(index < 0 || index > lst->length) {
		return NULL;
	}
	if(lst->length == 0) {
		return NULL;
	}
	nodeptr cur = lst->head->next;

	for(int i = 0; i != index; i++) {
		cur = cur->next;
	}

	return cur->data;
}

int removeFromList(listptr lst, int index) {
	if(index < 0 || index > lst->length) {
		return 0;
	}
	if(lst->length == 0) {
		return 0;
	}
	if(index == 0 && lst->length >= 2) {
		lst->head->next = lst->head->next->next;
		lst->length--;
		return 1;
	}
	if(index == 0) {
		lst->head->next = NULL;
		lst->length--;
		return 1;
	}

	nodeptr cur = lst->head->next;

	for(int i = 0; i != index-1; i++) {
			cur = cur->next;
	}

	if(cur->next->next == NULL) {
		cur->next = NULL;
		//free(cur->next);
	} else {
		nodeptr temp = cur->next;
		cur->next = cur->next->next;
		//free(cur->next);
	}
	lst->length--;
	return 1;
}

int getLength(listptr lst) {
	return lst->length;
}
