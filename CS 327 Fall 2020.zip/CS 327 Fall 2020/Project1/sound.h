/*
 * sound.h
 *
 *  Created on: Sep 30, 2020
 *      Author: alexthompson
 */

#ifndef SOUND_H_
#define SOUND_H_

/**
 * A sound is a collection of samples of a particular wave (sine, triangle, etc)
 * over a period of time. Length should be equal to the duration*rate of a wave.
 */
typedef struct sound_t {
	int length;
	float rate;
	float* samples;

}	sound;

/**
 * A singlewave represents a wave of a particular type ("sine", "triangle", etc).
 * Since we do not know all of the information needed to make a wave when we read
 * a wave, we simply keep it in here and add it to a list until we need it.
 * Delay and attenuation are parameters for reverb to be applied when the wave
 * is to be made. They should be 0 if there is none.
 * The delay, attenuation, and type are supplied when a wave is read from a
 * song file.
 */
typedef struct singlewave_t {
	char* type;
	float delay;
	float attenuation;

} 	singlewave;

/**
 * A "mix" represents one or more individual waves to be mixed together when the
 * time comes for waves to be generated at a given frequency. The volumes is an array
 * that each respective singlewave should be played at.
 */
typedef struct mixed_t {
	singlewave* waves;
	float* volumes;
	int numwaves;
}	mixed;

/**
 * A songnote is the culmination of a mix type that has been processed together with
 * generated singlewaves at frequency key. "start" is the time at which the note plays
 * in the song, and "duration" is how long it plays for. The "atSample" variable keeps
 * track of what sample should be played during the note's lifespan. When atSample reaches
 * s->length, the note is over.
 */
typedef struct songnote_t {
	sound* s;
	int key;
	float start;
	float duration;
	int atSample;

}	note;

#endif /* SOUND_H_ */
