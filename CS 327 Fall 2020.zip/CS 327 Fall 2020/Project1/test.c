#include <stdlib.h>
#include <stdio.h>
#include "gensnd.h"
#include "process.h"
#include "iosnd.h"

int main(int argc, char** argv) {
	//printf("called");
	sound* s;
	FILE* f;

	char* f_name = argv[1];

	f = fopen(f_name, "w+");

	//printf("calling saw...");
	//s = genTriangle(220.0, 16000.0, 3);

	//outputSound(s, f);

	return 0;
}
