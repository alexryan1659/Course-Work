#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "gensnd.h"

float pi = M_PI;

sound* gensine(float hertz, float sample_rate, float duration) {

	//check for invalid input
	if(sample_rate < 0 || duration < 0) {
			return NULL;
	}
	sound* s = (sound*)malloc(sizeof(sound));
	int samples = sample_rate*duration;
	s->samples = (float*)malloc(samples * sizeof(float));
	s->rate = sample_rate;
	s->length = (int)samples;

	float w = sample_rate/hertz;
	for(int i = 0; i < samples; ++i) {
		s->samples[i] = sin(2*pi*hertz*i/sample_rate);
	}

	return s;
}

sound* genDTMF(char key, float sample_rate, float duration) {
	sound s1;
	sound s2;
	static sound s;
	float samples = sample_rate*duration;
	s.samples = (float*)malloc(samples * sizeof(float));
	s.rate = sample_rate;
	s.length = samples;

	switch(key) {

	case 35: //'#'
		s1 = *gensine(941.0, sample_rate, duration);
		s2 = *gensine(1477.0, sample_rate, duration);
		break;

	case 42: //'*'
		s1 = *gensine(941.0, sample_rate, duration);
		s2 = *gensine(1209.0, sample_rate, duration);
		break;

	case 48: //'0'
		s1 = *gensine(941.0, sample_rate, duration);
		s2 = *gensine(1336.0, sample_rate, duration);
		break;

	case 49: //'1'
		s1 = *gensine(697.0, sample_rate, duration);
		s2 = *gensine(1209.0, sample_rate, duration);
		break;

	case 50: //'2'
		s1 = *gensine(697.0, sample_rate, duration);
		s2 = *gensine(1336.0, sample_rate, duration);
		break;

	case 51: //'3'
		s1 = *gensine(697.0, sample_rate, duration);
		s2 = *gensine(1477.0, sample_rate, duration);
		break;

	case 52: //'4'
		s1 = *gensine(770.0, sample_rate, duration);
		s2 = *gensine(1209.0, sample_rate, duration);
		break;

	case 53: //'5'
		s1 = *gensine(770.0, sample_rate, duration);
		s2 = *gensine(1336.0, sample_rate, duration);
		break;

	case 54: //'6'
		s1 = *gensine(770.0, sample_rate, duration);
		s2 = *gensine(1477.0, sample_rate, duration);
		break;

	case 55: //'7'
		s1 = *gensine(852.0, sample_rate, duration);
		s2 = *gensine(1209.0, sample_rate, duration);
		break;

	case 56: //'8'
		s1 = *gensine(852.0, sample_rate, duration);
		s2 = *gensine(1336.0, sample_rate, duration);
		break;

	case 57: //'9'
		s1 = *gensine(852.0, sample_rate, duration);
		s2 = *gensine(1477.0, sample_rate, duration);
		break;

	case 65: //'A'
		s1 = *gensine(697.0, sample_rate, duration);
		s2 = *gensine(1633.0, sample_rate, duration);
		break;

	case 66: //'B'
		s1 = *gensine(770.0, sample_rate, duration);
		s2 = *gensine(1633.0, sample_rate, duration);
		break;

	case 67: //'C'
		s1 = *gensine(852.0, sample_rate, duration);
		s2 = *gensine(1633.0, sample_rate, duration);
		break;

	case 68: //'D'
		s1 = *gensine(941.0, sample_rate, duration);
		s2 = *gensine(1633.0, sample_rate, duration);
		break;

	case 97: //'a'
		s1 = *gensine(697.0, sample_rate, duration);
		s2 = *gensine(1633.0, sample_rate, duration);
		break;

	case 98: //'b'
		s1 = *gensine(770.0, sample_rate, duration);
		s2 = *gensine(1633.0, sample_rate, duration);
		break;

	case 99: //'c'
		s1 = *gensine(852.0, sample_rate, duration);
		s2 = *gensine(1633.0, sample_rate, duration);
		break;

	case 100: //'d'
		s1 = *gensine(941.0, sample_rate, duration);
		s2 = *gensine(1633.0, sample_rate, duration);
		break;
	}

	for(int i = 0; i < samples; ++i) {
		s.samples[i] = (s1.samples[i] + s2.samples[i])/2;
	}

	free(s1.samples);
	free(s2.samples);

	return &s;
}

sound* genSilence(float sample_rate, float duration) {
	static sound s;

	float samples = sample_rate*duration;
	s.samples = (float*)malloc(samples * sizeof(float));
	s.rate = sample_rate;
	s.length = samples;

	for(int t = 0; t < samples; ++t) {
		s.samples[t] = 0.0;
	}

	return &s;
}

/////////////////
// PART C CODE //
/////////////////

/**
 * Helper function to determine the sign of given value x.
 */
int sgn(float x) {
	if(x > 0) {
		return 1;
	} else if(x < 0) {
		return -1;
	} else {
		return 0;
	}
}

sound* genSquare(float hertz, float sample_rate, float duration) {
	sound* s = malloc(sizeof(sound));
	float samples = sample_rate*duration;
	s->rate = sample_rate;
	s->length = (int) samples;
	s->samples = (float*)malloc(samples * sizeof(float));
	//sgn(sin(2*pi*f*t)

	for(int i = 0; i < samples; ++i) {
		s->samples[i] = sgn(sin(2*pi*hertz*i/sample_rate));
	}

	return s;
}

sound* genTriangle(float hertz, float sample_rate, float duration) {
	sound* s = malloc(sizeof(sound));
	float samples = sample_rate*duration;
	s->rate = sample_rate;
	s->length = (int) samples;
	s->samples = (float*)malloc(samples * sizeof(float));

	for(int i = 0; i < samples; i++) {
		float w = ((i*hertz)/sample_rate);
		s->samples[i] = 2.0*fabs(2.0*(w-floor((1.0/2.0) + w)))-1.0;
	}

	return s;
}

sound* genSawtooth(float hertz, float sample_rate, float duration) {
	sound* s = malloc(sizeof(sound));

	float samples = sample_rate*duration;
	s->rate = sample_rate;
	s->length = (int) samples;
	s->samples = (float*)malloc(samples * sizeof(float));

	for(int i = 0; i < samples; i++) {
		float w = ((i*hertz)/sample_rate);
		s->samples[i] = 2.0*(w-floor((1.0/2.0) + w));
	}
	return s;
}
