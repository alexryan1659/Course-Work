#include "iosnd.h"

int outputSound(sound *s, FILE *f) {

	//ensure s and f are not null
	if(s || f) {
		int num = s->length;
		for(int i = 0; i < num; ++i) {
			fprintf(f, "%f\n", s->samples[i]);
		}
	} else {
		printf("Sound or file is invalid.");
	}

	return 0;
}
