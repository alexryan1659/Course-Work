#include <stdlib.h>
#include <stdio.h>
#include "sound.h"
/*
 * iosnd.h
 *
 *  Created on: Sep 30, 2020
 *      Author: alexthompson
 */

#ifndef IOSND_H_
#define IOSND_H_

/**
 * Outputs a single sound to a file pointed by *f.
 */
int outputSound(sound *s, FILE *f);

#endif /* IOSND_H_ */
