#include "sound.h"
/*
 * process.h
 *
 *  Created on: Oct 4, 2020
 *      Author: alexthompson
 */

#ifndef PROCESS_H_
#define PROCESS_H_

/**
 * Mixes an array of sounds together, multiplied by the volumes in w[].
 * c is the number of volumes in w[] and sounds in s[].
 */
sound* mix(sound* s[], float w[], int c);

/**
 * Modulate multiplies, sample-by-sample, two sounds together.
 */
sound* modulate(sound* s1, sound* s2);

/**
 * A filter for creating multiple effects.
 */
sound* filter(sound* s, float fir[], int c);

/**
 * Applies reverb to a sound given delay and attenuation. Attenuation should
 * be less than 1 and greater than 0, and delay should be greater than 0 and
 * less than 0.1 seconds
 */
sound* reverb(sound* s, float delay, float attenuation);


/**
 * Similar to reverb(), creates an echo effect. Delay should be
 * between 0.1 and 1 second.
 */
sound* echo(sound* s, float delay, float attenuation);

#endif /* PROCESS_H_ */
