#include "sound.h"
/*
 * gensnd.h
 *
 *  Created on: Sep 30, 2020
 *      Author: alexthompson
 */

#ifndef GENSND_H_
#define GENSND_H_

/**
 * Generates a sine wave given a frequency (hertz), sample_rate, and duration (seconds).
 */
sound* gensine(float hertz, float sample_rate, float duration);

sound* genDTMF(char key, float sample_rate, float duration);

sound* genSilence(float sample_rate, float duration);

/**
 * Generates a square wave given a frequency (hertz), sample_rate, and duration (seconds).
 */
sound* genSquare(float hertz, float sample_rate, float duration);

/**
 * Generates a triangle wave given a frequency (hertz), sample_rate, and duration (seconds).
 */
sound* genTriangle(float hertz, float sample_rate, float duration);

/**
 * Generates a sawtooth wave given a frequency (hertz), sample_rate, and duration (seconds).
 */
sound* genSawtooth(float hertz, float sample_rate, float duration);

#endif /* GENSND_H_ */
