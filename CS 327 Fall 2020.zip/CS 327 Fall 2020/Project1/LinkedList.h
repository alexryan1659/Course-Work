/*
 * LinkedList.h
 *
 *  Created on: Oct 10, 2020
 *      Author: alexthompson
 */
#ifndef LINKEDLIST_H_
#define LINKEDLIST_H_

typedef struct node_t node;
typedef struct node_t* nodeptr;

/**
 * A node that holds a pointer to some data and the next node in a Linked List
 * Unique to this program, nodes have a "name" that identifies it, allowing
 * for the searching of notes, waves, and mixed waves.
 */
struct node_t {
	void* data;
	char* name;
	nodeptr next;

};

typedef struct list_t list;
typedef struct list_t* listptr;

/**
 * A Linked List. The head points to the beginning of the list, so the list
 * actually begins at head->next.
 */
struct list_t {
	nodeptr head;
	int length;
};

/**
 * Creates a new Linked List and returns a pointer to said list.
 */
listptr createList();

/**
 * Adds a new node to the end of the list that holds the value data.
 */
int add(listptr lst, void* data, char name[]);

/**
 * Searches for the name of a node and returns the data in that node.
 * Returns NULL if not found.
 */
void* searchByName(listptr lst, char name[]);

/**
 * Returns the data in the node at index of the Linked List.
 * Returns NULL if index is negative or larger than the list size.
 */
void* getByIndex(listptr lst, int index);

/**
 * Removes the node at index.
 * Returns NULL if index is negative or larger than the list size.
 */
int removeFromList(listptr lst, int index);

/**
 * Returns the length of a Linked List
 */
int getLength(listptr lst);



#endif /* LINKEDLIST_H_ */
