#include <stdlib.h>
#include "process.h"

sound* mix(sound* s[], float w[], int c) {
	sound** ret_s = malloc(sizeof(sound*));
	int length = 0;
	for(int i = 0; i < c; i++) {
		if(s[i]->length > length) {
			length = s[i]->length;
		}
	}

	ret_s->length = length;
	ret_s->rate = length;
	ret_s->samples = malloc(length*sizeof(float));

	//for each sample t in ret_s
	for(int t = 0; t < ret_s->length; t++) {
		float sample = 0.0;
		//for each sound a in s[]
		for(int i = 0; i < c; i++) {
			sound* a = s[i];
			float vol = w[i];
			if(t > a->length) {
				sample += 0.0;
			} else {
				sample += (a->samples[t]*vol)/2.0;
			}
		}
		ret_s->samples[t] = sample;
		//printf("%f\n", sample);
	}
	return ret_s;
}

sound* modulate(sound* s1, sound* s2) {
	if(s1->length != s2->length) {
		return NULL;
	}
	sound* s = malloc(sizeof(sound));
	s->length = s1->length;
	s->rate = s1->rate;
	s->samples = (float*)malloc(s1->length * sizeof(float));

	for(int i = 0; i != s->length; i++) {
		s->samples[i] = s1->samples[i] * s2->samples[i];
	}

	return s;
}

sound* filter(sound* s, float fir[], int c) {

	for(int j = 0; j != c-1; j++) {
		for(int i = 0; i != s->length; i++) {
			if(i-j < 0) {
				s->samples[i] += 0;
			} else {
				s->samples[i] += (s->samples[i-j]*fir[j])/2.0;
			}
		}
	}

	return s;
}

sound* reverb(sound* s, float delay, float attenuation) {

	if(!(attenuation < 1.0 && attenuation > 0.0) || !(delay > 0.0 && delay < 0.1)) {
		return NULL;
	}
	if(s == 0) {
		return NULL;
	}

	float* fir = malloc((delay*s->length)*sizeof(float));
	if(fir == NULL) {
		printf("memory allocation error!\n");
	}
	fir[0] = 1;
	fir[(int)(delay*s->rate)] = attenuation;
	s = filter(s, fir, delay*s->length);

	return s;
}

sound* echo(sound* s, float delay, float attenuation) {

	if(!(attenuation < 1.0 && attenuation > 0.0) || !(delay > 0.1 && delay < 1.0)) {
		return NULL;
	}
	if(s == 0) {
		return NULL;
	}

	float* fir = malloc((delay*s->length)*sizeof(float));
	fir[0] = 1;
	fir[(int)(delay*s->rate)] = attenuation;

	s = filter(s, fir, delay*s->length);

	return s;
}
