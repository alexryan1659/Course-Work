#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "sound.h"
#include "gensnd.h"
#include "process.h"
#include "iosnd.h"
#include "LinkedList.h"

/**
 * Generates a frequency given a key n.
 */
float keyFrequency(int n) {
	return (float)pow(2.0, (n-49.0)/12.0)*440.0;
}

/**
 * Generates a wave type given a frequency (hertz), sample rate, duration (seconds),
 * and type based on a string identifier.
 */
sound* genWave(float frequency, float sample_rate, float duration, char type[]) {
	if(strcmp(type, "sine") == 0) {
		return gensine(frequency, sample_rate, duration);
	} else

	if(strcmp(type, "square") == 0) {
		return genSquare(frequency, sample_rate, duration);
	} else

	if(strcmp(type, "triangle") == 0) {
		return genTriangle(frequency, sample_rate, duration);
	} else

	if(strcmp(type, "saw") == 0) {
		return genSawtooth(frequency, sample_rate, duration);
	}
	return NULL;
}

int main(int argc, char** argv) {

	FILE* f;
	char* f_name = argv[1];
	FILE* f_out;
	char* out_name = argv[2];

	f = fopen(f_name, "r");

	char line[255];
	char sr[] = "SAMPLERATE";
	char wave[] = "WAVE";
	char snd[] = "SOUND";
	char song[] = "SONG";
	int sample_rate;
	int numNotes;
	float totalDuration = 0.0;

	list* wavelist = createList();

	list* soundlist = createList();

	list* notelist = createList();

	char keyword[12];
	while(fgets(line, 255, f)) {
		sscanf(line, "%s", keyword);
		//printf("key word: %s\n", keyword);
		printf("%s", line);
		if(strcmp(keyword, sr) == 0) {
			fgets(line, 255, f);
			sscanf(line, "%d", &sample_rate);
			printf("%d\n", sample_rate);
			fgets(line, 255, f);
		}

		if(strcmp(keyword, wave) == 0) {
			//printf("%s", line);
			char name[255];
			fgets(line, 255, f);
			sscanf(line, "%s", name);

			char type[9];
			fgets(line, 255, f);
			sscanf(line, "%s", type);

			float delay;
			float attenuation;
			fgets(line, 255, f);
			sscanf(line, "%f %f", &delay, &attenuation);

			singlewave* w = malloc(sizeof(singlewave));
			w->type = malloc(strlen(type)+1);
			strcpy(w->type, type);
			w->delay = delay;
			w->attenuation = attenuation;

			add(wavelist, w, name);
			fgets(line, 255, f);
		}

		if(strcmp(keyword, snd) == 0) {
			//printf("%s", line);
			char sndname[255];
			fgets(line, 255, f);
			sscanf(line, "%s", sndname); //sound name
			singlewave *waves[255];
			float volumes[255];
			int numwaves = 0;
			char wvename[255];
			float vol;
			fgets(line, 255, f);
			while(strcmp(line, "\n") != 0 && strcmp(line, "\n") != 3) {
				sscanf(line, "%s %f", wvename, &vol);
				waves[numwaves] = searchByName(wavelist, wvename);
				volumes[numwaves] = vol;
				numwaves++;
				fgets(line, 255, f);
			}
			mixed* m = malloc(sizeof(mixed));
			if(m == NULL) {
				printf("memory allocation error!\n");
			}
			m->waves = malloc(numwaves * sizeof(singlewave));
			for(int i = 0; i < numwaves; i++) {
				m->waves[i] = *waves[i];
			}
			m->volumes = volumes;
			m->numwaves = numwaves;
			add(soundlist, m, sndname);
		}

		if(strcmp(keyword, song) == 0) {
			char sndname[255];
			int key;
			float time;
			float duration;
			while(fgets(line, 255, f)) {
                   	   	   	    sscanf(line, "%s %d %f %f", sndname, &key, &time, &duration);
                                float frequency = keyFrequency(key);
                                mixed* m = searchByName(soundlist, sndname);
                                sound** sounds = malloc(m->numwaves * sizeof(sound*));
                                for(int i = 0; i < m->numwaves; i++) {
                                		sounds[i] = genWave(frequency, sample_rate, duration, m->waves[i].type);
                                        if(!(m->waves[i].delay == 0 || m->waves[i].attenuation == 0)) {
                                                sounds[i] = reverb(sounds[i], m->waves[i].delay, m->waves[i].attenuation);
                                        }

                                }
                                note* n = malloc(sizeof(note));
                                n->key = key;
                                n->duration = duration;
                                n->s = mix(sounds, m->volumes, m->numwaves);
                                n->start = time*sample_rate;
                                n->atSample = 0;
                                if(duration + time > totalDuration) {
                                        totalDuration = duration + time;
                                }
                                add(notelist, n, "");
                                numNotes++;
                                }
                        }
		}

	free(wavelist);
	free(soundlist);

	f_out = fopen(out_name, "w");
	printf("%f\n", totalDuration);

	list* activeList = createList();

	//start playing song
	printf("beggining song\n");
	for(float i = 0.0; i < totalDuration*sample_rate; i += 1.0) {
		for(int j = 0; j != notelist->length; j++) {
			note* n = getByIndex(notelist, j);
			if(n->start == i) {
				add(activeList, n, "");
			}
		}
		if(getLength(activeList) == 0) {
			fprintf(f_out, "%f\n", 0.0);
		}
		float sample = 0.0;
		for(int j = 0; j != activeList->length; j++) {
			note* n = getByIndex(activeList, j);
			if(n == NULL) {
				break;
			}
			if(n->atSample >= n->s->length) {
				removeFromList(activeList, j);
			}
			sample += n->s->samples[n->atSample];
			n->atSample++;
		}
		fprintf(f_out, "%f\n", sample);
	}

	fclose(f);
	fclose(f_out);
	return 0;
}
