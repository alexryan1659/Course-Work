#include<string>
#include<cmath>
#include"wave.h"
#include"SoundSamples.h"
using namespace std;

float pi = M_PI;

/**
 * Returns the sign of a number x. 1 for positive, -1 for negative, 0 for 0.
 */
int sgn(float x) {
	if(x > 0) {
		return 1;
	} else if(x < 0) {
		return -1;
	} else {
		return 0;
	}
}

/**
 * Default constructor for a wave
 */
Wave::Wave() {
	name = "";
	type = 0;
}

/**
 * Creates a wave with the given name
 */
Wave::Wave(string name) {
	this->name = name;
	type = 0;
}

/**
 * Destructor for a wave
 */
Wave::~Wave() {
	//not sure what to put here.
	delete this;
}

/**
 * Returns the name of this wave
 */
string Wave::getName() {
	return this->name;
}

/**
 * Generates the correct samples based on the type of wave to generate, given frequency,
 * sample rate, and duration.
 */
SoundSamples* Wave::generateSamples(float frequency, float samplerate, float duration) {
	float samples = samplerate*duration;
	SoundSamples* s = new SoundSamples(new float[(int)samples], (int)samples, samplerate);

	if(type == 1) {
		//sine wave
		float w = samplerate/frequency;
		for(int i = 0; i != samples; i++) {
			(*s)[i] = generateFunction(2*pi*frequency*i/samplerate);
		}
		return s;
	} else if(type == 2) {
		//square wave
		float w = samplerate/frequency;
		for(int i = 0; i != samples; i++) {
			(*s)[i] = sgn(generateFunction(2*pi*frequency*i/samplerate));
		}
		return s;

	} else if(type == 3) {
		//triangle wave
		for(int i = 0; i < samples; i++) {
		float w = ((i*frequency)/samplerate);
			(*s)[i] = generateFunction(w);
		}
		return s;
	} else if(type == 4){
		//sawtooth wave
		for(int i = 0; i < samples; i++) {
			float w = ((i*frequency)/samplerate);
			(*s)[i] = 2.0*(w-floor((1.0/2.0) + w));
		}
		return s;
	}

	return nullptr;
}
