/*
 * SoundSamples.h
 *
 *  Created on: Nov 1, 2020
 *      Author: alexthompson
 */

#ifndef SOUNDSAMPLES_H_
#define SOUNDSAMPLES_H_

/**
 *  A class to represent samples of a sound, along with its length and sample rate
 */
class SoundSamples {
public:
	//constructors
	SoundSamples(); //default
	SoundSamples(float* samples, int length, float rate);
	SoundSamples(int length, float rate);
	SoundSamples(SoundSamples& ss); //copy constructor
	~SoundSamples();

	//methods
	int getSampleRate();
	int getLength();
	void reverb2(float delay, float attenuation);
	void adsr(float atime, float alevel, float dtime, float slevel, float rtime);

	//overloaded operators
	SoundSamples& operator=(SoundSamples& s);
	float& operator[](int i);
	SoundSamples& operator+(SoundSamples& s);
private:
	//member variables
	float samplerate;
	int length;
	float* samples;
};



#endif /* SOUNDSAMPLES_H_ */
