/*
 * wave.h
 *
 *  Created on: Nov 1, 2020
 *      Author: alexthompson
 */
#include<string>
#include<cmath>
#include"SoundSamples.h"
#ifndef WAVE_H_
#define WAVE_H_
using namespace std;

/**
 * A class to represent any of sine, square, triangle, or sawtooth waves.
 */
class Wave {
public:
	Wave();
	Wave(string name);
	virtual ~Wave() = 0; //gets rid of annoying warning
	SoundSamples* generateSamples(float frequency, float samplerate, float duration);
	virtual float generateFunction(float time) = 0; //unique function to any subclass
	string getName();

protected:
	string name;
	int type; //defines the type of wave, 1=SineWave, etc.
};

/**
 * A sine wave
 */
class SineWave : public Wave {
	public:
		SineWave(string name) {
			this->name = name;
			type = 1;
		}
		float generateFunction(float time) {

			return sin(time);
		}
};

/**
 * A square wave
 */
class SquareWave : public Wave {
	public:
		SquareWave(string name) {
			this->name = name;
			type = 2;
		}
		float generateFunction(float time) {
			return sin(time);
		}
};

/**
 * A triangle wave
 */
class TriangleWave : public Wave {
	public:
		TriangleWave(string name) {
			this->name = name;
			type = 3;
		}
		float generateFunction(float time) {
			return 2.0*fabs(2.0*(time-floor((1.0/2.0) + time)))-1.0;
		}
};

/**
 * A sawtooth wave
 */
class SawtoothWave : public Wave {
	public:
		SawtoothWave(string name) {
			this->name = name;
			type = 4;
		}
		float generateFunction(float time) {
			return 2.0*(time-floor((1.0/2.0) + time));
		}
};

#endif /* WAVE_H_ */
