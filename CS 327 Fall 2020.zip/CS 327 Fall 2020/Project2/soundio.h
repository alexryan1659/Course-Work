/*
 * SoundIO.h
 *
 *  Created on: Nov 4, 2020
 *      Author: alexthompson
 */
#include<string>
#include"SoundSamples.h"
#ifndef SOUNDIO_H_
#define SOUNDIO_H_
using namespace std;

class SoundIO {
public:
	static void OutputSound(SoundSamples* s, string filename);
};

#endif /* SOUNDIO_H_ */
