#include <cstdlib>
#include <cmath>
#include <iostream>
#include "SoundSamples.h"
using namespace std;

/**
 * Default constructor. Initializes with length 0, sample rate 8000, and no samples.
 */
SoundSamples::SoundSamples() {
	length = 0;
	samplerate = 8000;
	samples = new float[this->length];
}

/**
 * Creates a new SoundSamples with given list of samples, length, and sample rate.
 */
SoundSamples::SoundSamples(float* samples, int length, float rate) {
	samplerate = rate;
	this->length = length;
	this->samples = new float[this->length];
	for(int i = 0; i != this->length; i++) {
		this->samples[i] = samples[i];
	}
}

/**
 * Creates a SoundSamples with given length and sample rate, and samples set to 0.
 */
SoundSamples::SoundSamples(int length, float rate) {
	samplerate = rate;
	this->length = length;
	samples = new float[this->length];
	for(int i = 0; i != this->length; i++) {
		this->samples[i] = 0.0;
	}
}

/**
 * Creates a new SoundSamples with the existing properties of another SoundSamples
 */
SoundSamples::SoundSamples(SoundSamples& s) {
	delete[] samples;
	if(s.samples) {
		samples = new float[this->length];
		samplerate = s.samplerate;
		length = s.length;
		for(int i = 0; i != this->length; i++) {
			samples[i] = s.samples[i];
		}
	} else {
		s.samples = nullptr;
	}
}

/**
 * Destructor
 */
SoundSamples::~SoundSamples() {
	delete samples;
}

/**
 * Quick assignment operator
 */
SoundSamples& SoundSamples::operator =(SoundSamples& s) {
	delete[] samples;
	if(this != &s) {
		if(s.samples) {
			samplerate = s.samplerate;
			length = s.length;
			samples = new float[this->length];
			for(int i = 0; i != this->length; i++) {
				samples[i] = s.samples[i];
			}
		} else {
			s.samples = nullptr;
		}
	}
	return *this;
}

/**
 * Allows quick retrieval of a particular sample, i.e., s[0] returns the first sample
 * in a SoundSamples s.
 */
float& SoundSamples::operator[](int i) {
	if(i > length || i < 0) {
		cout << "index out of bounds" << endl;
		return samples[0];
	}
	return samples[i];
}

/**
 * Appends the samples of one SoundSamples to another, updating the length appropriately
 */
SoundSamples& SoundSamples::operator +(SoundSamples& s) {
	float* newsamples = new float[this->length + s.length];

	for(int k = 0; k != this->length; k++) {
		newsamples[k] = this->samples[k];
	}

	int i = this->length;
	for(int j = 0; j != s.length; j++) {
		newsamples[i] = s.samples[j];
		i++;
	}

	this->length = this->length + s.length;
	this->samples = newsamples;

	return *this;
}

/**
 * Returns the sample rate of this SoundSample
 */
int SoundSamples::getSampleRate() {
	return samplerate;
}

/**
 * Returns the length of this SoundSample
 */
int SoundSamples::getLength() {
	return length;
}

void SoundSamples::reverb2(float delay, float attenuation) {
	if(delay < 0.0 || attenuation < 0.0) {
		return;
	}
	float* newsamples = new float[this->length];

	int sdelay = round(delay*this->samplerate);
	for(int i = 0; i != this->length; i++) {
		if(i-sdelay < 0 || newsamples[i-sdelay] == 0) {
			newsamples[i] = this->samples[i];
		} else {
			newsamples[i] = this->samples[i] + newsamples[i-sdelay]*attenuation;
		}
	}

	delete this->samples;
	this->samples = newsamples;
}

void SoundSamples::adsr(float atime, float alevel, float dtime, float slevel, float rtime) {
	float adsrsamples[this->length];
	if(atime < 0 || dtime < 0 || rtime < 0) {
		return;
	}
	if(slevel > alevel) {
		return;
	}

	float w = 0.0;
	int totalsampletime = 0;
	for(int i = 0; i != atime && totalsampletime != this->length; i++) {
		adsrsamples[i] = w;
		w += alevel/atime;
		totalsampletime++;
	}
	//w should now equal alevel
	for(int i = 0; i != dtime && totalsampletime != this->length; i++) {
		adsrsamples[totalsampletime] = w;
		w -= slevel/dtime;
		totalsampletime++;
	}
	w = slevel;
	while(totalsampletime != ((this->length - rtime)-1) && totalsampletime != this->length) {
		adsrsamples[totalsampletime] = w;
		totalsampletime++;
	}
	for(int i = 0; i != rtime && totalsampletime != this->length; i++) {
		adsrsamples[totalsampletime] = w;
		w -= slevel/rtime;
		totalsampletime++;
	}

	for(int i = 0; i != this->length; i++) {
		(*this)[i] *= adsrsamples[i];
	}
	(*this)[(this->length)-1] = 0.0;
}
