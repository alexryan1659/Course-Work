#include<iostream>
#include<fstream>
#include"soundio.h"
#include"SoundSamples.h"
using namespace std;
//using namespace ios;

/**
 * Outputs the samples of a SoundSamples to a file, given by filename
 */
void SoundIO::OutputSound(SoundSamples* s, string filename) {
	ofstream f;
	f.open(filename, ios::app);

	std::cout.precision(6);

	for(int i = 0; i != s->getLength(); i++) {
		f << (*s)[i] << std::fixed << endl;
	}
	f.close();
}
