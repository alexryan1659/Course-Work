#include <iostream>
#include "SoundSamples.h"
#include "wave.h"
#include "soundio.h"
using namespace std;

/**
 * A program to generate samples of a sine, square, triangle, or sawtooth wave
 */
int main() {


	float* f = new float[17];
	f[0] = 1.0;
	f[1] = 1.0;
	f[2] = 1.0;
	f[3] = 1.0;
	f[4] = 1.0;
	f[5] = 1.0;
	f[6] = 1.0;
	f[7] = 1.0;
	f[8] = 1.0;
	f[9] = 1.0;
	f[10] = 1.0;
	f[11] = 1.0;
	f[12] = 1.0;
	f[13] = 1.0;
	f[14] = 1.0;
	f[15] = 1.0;
	f[16] = 1.0;

	SoundSamples* s1 = new SoundSamples(f, 17, 1);
	s1->adsr(4, 0.5, 4, 0.25, 4);
	for(int i = 0; i != 17; i++) {
		cout << (*s1)[i] << endl;
	}

	/*
	int type = -1;
	float frequency = -1;
	float samplerate = -1;
	float duration = -1;
	string filename;

	//each while loop prompts the user over and over till input is valid

	cout << "1-Sine\n2-Square\n3-Triangle\n4-Sawtooth" << endl;
	while(true) {
		cout << "Enter a wave type defined above: ";
		cin >> type;
		if(type < 1 || type > 4) {
			cout << "Wave type must be 1,2,3, or 4 defined above.";
		} else {
			break;
		}
	}
	while(true) {
		cout << "\nEnter a sample rate: ";
		cin >> samplerate;
		if(samplerate <= 0) {
			cout << "Sample rate must be greater than 0.";
		} else {
			break;
		}
	}
	while(true) {
		cout << "\nEnter a frequency: ";
		cin >> frequency;
		if(frequency <= 0) {
			cout << "Frequency must be greater than 0.";
		} else {
			break;
		}
	}
	while(true) {
		cout << "\nEnter a duration: ";
		cin >> duration;
		if(duration < 0) {
			cout << "Duration cannot be less than 0.";
		} else {
			break;
		}
	}
	cout << "\nFinally, enter a file name to output to: ";
	cin >> filename;

	Wave* w;
	if(type == 1) {
		w = new SineWave("???"); //what was the point of naming?
	} else if(type == 2) {
		w = new SquareWave("???");
	} else if(type == 3) {
		w = new TriangleWave("???");
	} else if(type == 4) {
		w = new SawtoothWave("???");
	}

	SoundSamples* s = w->generateSamples(frequency, samplerate, duration);

	SoundIO::OutputSound(s, filename);

	*/
	return 0;
}
