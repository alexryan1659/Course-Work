#include <iostream>
#include <cmath>
#include <fstream>
#include "SoundSamples.h"
#include "wave.h"
#include "soundio.h"
using namespace std;

float keyFrequency(int n) {
	return (float)pow(2.0, (n-49.0)/12.0)*440.0;
}

int main() {

	int type = -1;
	float delay, attenuation; //reverb params
	float atime, alevel, dtime, slevel, rtime; //adsr params
	float duration = 1;
	string filename;

	cout << "1-Sine\n2-Square\n3-Triangle\n4-Sawtooth" << endl;
	while(true) {
		cout << "Enter a wave type defined above: ";
		cin >> type;
		if(type < 1 || type > 4) {
			cout << "Wave type must be 1,2,3, or 4 defined above.";
		} else {
			break;
		}
	}
	cout << "What is the delay?" << endl;
	while(true) {
		cin >> delay;
		if(delay > 0.0) {
			break;
		}
		cout << "delay cannot be less than 0." << endl;
	}

	cout << "What is the attenuation?" << endl;
	while(true) {
		cin >> attenuation;
		if(attenuation > 0.0) {
			break;
		}
		cout << "attenuation cannot be less than 0." << endl;
	}

	cout << "What is the attack time?" << endl;
	while(true) {
		cin >> atime;
		if(atime > 0.0) {
			break;
		}
		cout << "attack time cannot be less than 0." << endl;
	}

	cout << "What is the attack level?" << endl;
	while(true) {
		cin >> alevel;
		if(alevel > 0.0) {
			break;
		}
		cout << "attack level cannot be less than 0." << endl;
	}

	cout << "What is the decay time?" << endl;
	while(true) {
		cin >> dtime;
		if(dtime > 0.0) {
			break;
		}
		cout << "decay time cannot be less than 0." << endl;
	}

	cout << "What is the sustain level?" << endl;
	while(true) {
		cin >> slevel;
		if(slevel > 0.0) {
			break;
		}
		cout << "sustain level cannot be less than 0." << endl;
	}

	cout << "What is the release time?" << endl;
	while(true) {
		cin >> rtime;
		if(rtime > 0.0) {
			break;
		}
		cout << "release time cannot be less than 0." << endl;
	}

	cout << "\nEnter a file name to output to: " << endl;
	cin >> filename;

	Wave* w;
	if(type == 1) {
		w = new SineWave("???");
	} else if(type == 2) {
		w = new SquareWave("???");
	} else if(type == 3) {
		w = new TriangleWave("???");
	} else if(type == 4) {
		w = new SawtoothWave("???");
	}

	cout << "Enter notes (1 through 88). To finish, input a negative number: " << endl;
	int key;
	SoundSamples* silence = new SoundSamples(16000*.25, 16000);
	ofstream f;
	f.open(filename, ios::out); //creates the file, leaves it blank
	f.close();

	while(true) {
		cin >> key;
		if(key < 0) {
			break;
		}
		SoundSamples* s = w->generateSamples(keyFrequency(key), 16000, duration);
		s->reverb2(delay, attenuation);
		s->adsr(atime, alevel, dtime, slevel, rtime);
		SoundIO::OutputSound(s, filename);
		SoundIO::OutputSound(silence, filename); //output silence
		delete s;
	}

	return 0;
}
